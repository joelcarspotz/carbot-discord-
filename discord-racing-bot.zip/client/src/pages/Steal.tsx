import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { StealModal } from "@/components/StealModal";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Steal() {
  const { toast } = useToast();
  const [showHistory, setShowHistory] = useState(false);
  
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'], // In a real app, this would be the logged-in user's ID
  });

  const { data: stealAttempts } = useQuery({
    queryKey: ['/api/users/1/steal-attempts'], // In a real app, this would use the actual user ID
    onError: () => {
      toast({
        title: "Error fetching steal attempts",
        description: "Could not retrieve your steal history",
        variant: "destructive"
      });
    }
  });

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockStealAttempts = [
    {
      id: 1,
      success: true,
      targetUsername: "VaultKeeper",
      carName: "Nissan GT-R",
      carRarity: "Rare",
      date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() // 3 days ago
    },
    {
      id: 2,
      success: false,
      targetUsername: "RacingKing",
      fine: 5000,
      date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString() // 10 days ago
    }
  ];

  // Calculate cooldown time (6 hours from last attempt)
  const lastAttempt = user?.lastStealAttempt ? new Date(user.lastStealAttempt) : null;
  const now = new Date();
  const cooldownHours = 6;
  const cooldownMs = cooldownHours * 60 * 60 * 1000;
  
  let cooldownRemaining = 0;
  let cooldownActive = false;
  
  if (lastAttempt) {
    const timeSinceLastAttempt = now.getTime() - lastAttempt.getTime();
    if (timeSinceLastAttempt < cooldownMs) {
      cooldownRemaining = cooldownMs - timeSinceLastAttempt;
      cooldownActive = true;
    }
  }
  
  // Format remaining time
  const formatRemainingTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Car Theft</h1>
        <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
          <i className="fas fa-coins text-[#FEE75C] mr-2"></i>
          <span className="font-medium">{user?.balance?.toLocaleString() || '25,750'}</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="bg-[#2F3136] border-gray-700 col-span-1 md:col-span-2 p-6">
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-[#ED4245] rounded-full flex items-center justify-center text-white mr-3">
              <i className="fas fa-key text-xl"></i>
            </div>
            <div>
              <h2 className="text-white font-bold text-xl">Car Theft System</h2>
              <p className="text-[#DCDDDE]">Attempt to steal cars from other players</p>
            </div>
          </div>
          
          <div className="bg-[#36393F] rounded-lg p-4 mb-4">
            <h3 className="text-white font-semibold mb-2">How it works</h3>
            <ul className="space-y-2 text-[#DCDDDE]">
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#ED4245] mt-1 mr-2"></i>
                <span>You have a 30% chance to successfully steal a random car from your target</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#ED4245] mt-1 mr-2"></i>
                <span>If you fail, you'll be fined ₵5,000</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#ED4245] mt-1 mr-2"></i>
                <span>You must wait 6 hours between theft attempts</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#ED4245] mt-1 mr-2"></i>
                <span>Targets must have at least one car in their garage</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-[#36393F] rounded-lg p-4 mb-4">
            <h3 className="text-white font-semibold mb-2">Cooldown Status</h3>
            {cooldownActive ? (
              <div className="flex items-center">
                <div className="w-10 h-10 bg-[#ED4245] bg-opacity-20 rounded-full flex items-center justify-center mr-3">
                  <i className="fas fa-hourglass-half text-[#ED4245]"></i>
                </div>
                <div>
                  <p className="text-[#DCDDDE]">
                    <span className="text-[#ED4245] font-medium">Cooldown active. </span> 
                    You can attempt another theft in {formatRemainingTime(cooldownRemaining)}.
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center">
                <div className="w-10 h-10 bg-[#57F287] bg-opacity-20 rounded-full flex items-center justify-center mr-3">
                  <i className="fas fa-check text-[#57F287]"></i>
                </div>
                <div>
                  <p className="text-[#DCDDDE]">
                    <span className="text-[#57F287] font-medium">Ready to steal! </span> 
                    You can attempt to steal a car now.
                  </p>
                </div>
              </div>
            )}
          </div>
          
          <StealModal trigger={
            <button 
              className={`w-full bg-[#ED4245] hover:bg-opacity-80 text-white py-3 rounded-md font-medium flex items-center justify-center ${cooldownActive ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={cooldownActive}
            >
              <i className="fas fa-key mr-2"></i>
              Attempt to Steal a Car
            </button>
          } />
        </Card>
        
        <Card className="bg-[#2F3136] border-gray-700 p-6">
          <h2 className="text-white font-bold text-xl mb-4 flex items-center">
            <i className="fas fa-exclamation-triangle text-[#FEE75C] mr-2"></i>
            Risk vs. Reward
          </h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-white font-medium mb-1">Success Rate</h3>
              <div className="h-8 w-full bg-[#36393F] rounded-full overflow-hidden">
                <div className="h-full bg-[#57F287]" style={{ width: '30%' }}>
                  <div className="flex h-full items-center justify-center text-xs font-bold text-white">
                    30%
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-medium mb-1">Failure Rate</h3>
              <div className="h-8 w-full bg-[#36393F] rounded-full overflow-hidden">
                <div className="h-full bg-[#ED4245]" style={{ width: '70%' }}>
                  <div className="flex h-full items-center justify-center text-xs font-bold text-white">
                    70%
                  </div>
                </div>
              </div>
            </div>
            
            <div className="pt-2">
              <h3 className="text-white font-medium mb-2">Rewards</h3>
              <div className="bg-[#36393F] rounded-lg p-3">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#57F287] bg-opacity-20 rounded-full flex items-center justify-center mr-2">
                    <i className="fas fa-car text-[#57F287]"></i>
                  </div>
                  <div>
                    <p className="text-[#DCDDDE]">Any car from the target's garage</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="pt-2">
              <h3 className="text-white font-medium mb-2">Penalties</h3>
              <div className="bg-[#36393F] rounded-lg p-3">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#ED4245] bg-opacity-20 rounded-full flex items-center justify-center mr-2">
                    <i className="fas fa-coins text-[#ED4245]"></i>
                  </div>
                  <div>
                    <p className="text-[#DCDDDE]">₵5,000 fine if caught</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
      
      <Card className="bg-[#2F3136] border-gray-700 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-white font-bold text-xl flex items-center">
            <i className="fas fa-history text-[#5865F2] mr-2"></i>
            Theft History
          </h2>
          <button 
            className="text-[#DCDDDE] text-sm hover:text-white"
            onClick={() => setShowHistory(!showHistory)}
          >
            {showHistory ? 'Hide History' : 'Show History'}
          </button>
        </div>
        
        {showHistory ? (
          <div className="space-y-3">
            {mockStealAttempts.map((attempt) => (
              <div key={attempt.id} className="bg-[#36393F] rounded-lg p-4">
                <div className="flex items-start">
                  <div className={`w-10 h-10 rounded-full ${attempt.success ? 'bg-[#57F287]' : 'bg-[#ED4245]'} flex items-center justify-center mr-3 flex-shrink-0`}>
                    <i className={`fas ${attempt.success ? 'fa-car' : 'fa-times'} text-white`}></i>
                  </div>
                  <div>
                    {attempt.success ? (
                      <p className="text-[#DCDDDE]">
                        You successfully stole a <span className="text-blue-400 font-medium">{attempt.carRarity} {attempt.carName}</span> from <span className="text-white font-medium">@{attempt.targetUsername}</span>
                      </p>
                    ) : (
                      <p className="text-[#DCDDDE]">
                        You failed to steal a car from <span className="text-white font-medium">@{attempt.targetUsername}</span> and were fined <span className="text-[#FEE75C]">₵{attempt.fine.toLocaleString()}</span>
                      </p>
                    )}
                    <p className="text-xs text-[#4F545C] mt-1">{new Date(attempt.date).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto bg-[#36393F] rounded-full flex items-center justify-center mb-3">
              <i className="fas fa-history text-[#DCDDDE] text-2xl"></i>
            </div>
            <h3 className="text-white font-medium mb-1">No Recent Theft Attempts</h3>
            <p className="text-[#DCDDDE] mb-4">Your theft history will appear here</p>
            <button 
              className="text-[#5865F2] hover:underline"
              onClick={() => setShowHistory(true)}
            >
              Show History
            </button>
          </div>
        )}
      </Card>
    </div>
  );
}
