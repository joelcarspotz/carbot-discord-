import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Car } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function Garage() {
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedView, setSelectedView] = useState("grid");
  const { toast } = useToast();
  
  // Use a dynamic user ID based on URL or default to user ID 1 (which has a proper username)
  const userId = 1; // Using a valid user ID from the database
  
  const { data: cars, isLoading } = useQuery<Car[]>({
    queryKey: [`/api/users/${userId}/cars`],
    onError: () => {
      toast({
        title: "Error fetching cars",
        description: "Could not retrieve your car collection",
        variant: "destructive"
      });
    }
  });

  const { data: userData } = useQuery({
    queryKey: [`/api/users/${userId}`],
  });

  // Pagination logic
  const carsPerPage = 6;
  const totalCars = cars?.length || 0;
  const totalPages = Math.max(1, Math.ceil(totalCars / carsPerPage));
  
  const startIndex = (currentPage - 1) * carsPerPage;
  const displayedCars = cars?.slice(startIndex, startIndex + carsPerPage) || [];

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(prev => prev - 1);
    }
  };

  const handleSetActive = (carId: number) => {
    toast({
      title: "Active Car Updated",
      description: "Your racing car has been updated",
    });
  };

  const handleSell = (carId: number, value: number) => {
    toast({
      title: "Sell Car",
      description: `Are you sure you want to sell this car for ₵${value.toLocaleString()}?`,
      action: (
        <Button
          variant="destructive"
          onClick={() => {
            toast({
              title: "Car Sold",
              description: `You sold your car for ₵${value.toLocaleString()}`,
            });
          }}
        >
          Confirm
        </Button>
      ),
    });
  };

  // Helper function for rarity color styling
  const getRarityStyles = (rarity: string) => {
    switch(rarity) {
      case 'Legendary':
        return {
          border: 'border-yellow-500',
          badge: 'bg-yellow-500',
          badgeText: 'text-black',
          bgColor: 'bg-yellow-500 bg-opacity-10',
          textColor: 'text-yellow-300'
        };
      case 'Epic':
        return {
          border: 'border-orange-500',
          badge: 'bg-orange-500',
          badgeText: 'text-white',
          bgColor: 'bg-orange-500 bg-opacity-10',
          textColor: 'text-orange-400'
        };
      case 'Rare':
        return {
          border: 'border-blue-500',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-blue-500 bg-opacity-10',
          textColor: 'text-blue-400'
        };
      case 'Uncommon':
        return {
          border: 'border-green-500',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-green-500 bg-opacity-10',
          textColor: 'text-green-500'
        };
      case 'Common':
        return {
          border: 'border-gray-700',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-green-500 bg-opacity-10',
          textColor: 'text-green-400'
        };
      default:
        return {
          border: 'border-gray-700',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-blue-500 bg-opacity-10',
          textColor: 'text-blue-400'
        };
    }
  };

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockCars: Car[] = [
    {
      id: 1,
      userId: 1,
      name: "McLaren P1",
      type: "Hypercar",
      rarity: "Legendary",
      speed: 95,
      acceleration: 90,
      handling: 85,
      boost: 80,
      value: 75000,
      image: "mclaren.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 2,
      userId: 1,
      name: "Ferrari 488",
      type: "Supercar",
      rarity: "Epic",
      speed: 90,
      acceleration: 85,
      handling: 85,
      boost: 75,
      value: 65000,
      image: "ferrari.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 3,
      userId: 1,
      name: "Porsche 911",
      type: "Sports Car",
      rarity: "Rare",
      speed: 80,
      acceleration: 85,
      handling: 90,
      boost: 65,
      value: 35000,
      image: "porsche.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 4,
      userId: 1,
      name: "Nissan GT-R",
      type: "Sports Car",
      rarity: "Rare",
      speed: 80,
      acceleration: 85,
      handling: 75,
      boost: 65,
      value: 30000,
      image: "gtr.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 5,
      userId: 1,
      name: "Toyota Supra",
      type: "Sports",
      rarity: "Uncommon",
      speed: 70,
      acceleration: 75,
      handling: 65,
      boost: 55,
      value: 15000,
      image: "supra.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 6,
      userId: 1,
      name: "Honda Civic",
      type: "Economy",
      rarity: "Common",
      speed: 55,
      acceleration: 60,
      handling: 70,
      boost: 40,
      value: 5000,
      image: "civic.svg",
      acquired: new Date().toISOString()
    }
  ];

  // Use real data if available, otherwise use mock data for UI demonstration
  const carList = displayedCars.length > 0 ? displayedCars : mockCars;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Your Garage</h1>
        <div className="flex space-x-3">
          <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
            <i className="fas fa-coins text-[#FEE75C] mr-2"></i>
            <span className="font-medium">{userData?.balance?.toLocaleString() || '25,750'}</span>
          </div>
          <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
            <i className="fas fa-car-side text-[#DCDDDE] mr-2"></i>
            <span className="font-medium">{totalCars || mockCars.length}/10</span>
          </div>
        </div>
      </div>

      <Card className="bg-[#2F3136] border-gray-700 mb-6">
        <div className="p-4 flex flex-col sm:flex-row justify-between">
          <div className="flex space-x-2 mb-3 sm:mb-0">
            <Button 
              variant={selectedView === 'grid' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setSelectedView('grid')}
              className={selectedView === 'grid' ? 'bg-[#5865F2]' : 'bg-[#36393F] text-[#DCDDDE]'}
            >
              <i className="fas fa-th-large mr-1"></i> Grid
            </Button>
            <Button 
              variant={selectedView === 'list' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setSelectedView('list')}
              className={selectedView === 'list' ? 'bg-[#5865F2]' : 'bg-[#36393F] text-[#DCDDDE]'}
            >
              <i className="fas fa-list mr-1"></i> List
            </Button>
          </div>
          
          <Tabs defaultValue="all" className="w-full sm:w-auto">
            <TabsList className="bg-[#36393F]">
              <TabsTrigger value="all" className="data-[state=active]:bg-[#5865F2]">All</TabsTrigger>
              <TabsTrigger value="legendary" className="data-[state=active]:bg-[#5865F2]">Legendary</TabsTrigger>
              <TabsTrigger value="rare" className="data-[state=active]:bg-[#5865F2]">Rare</TabsTrigger>
              <TabsTrigger value="common" className="data-[state=active]:bg-[#5865F2]">Common</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {Array(6).fill(0).map((_, index) => (
            <Card key={index} className="bg-[#2F3136] border-gray-700">
              <div className="p-3 flex justify-between items-center border-b border-gray-700">
                <Skeleton className="h-5 w-20 bg-[#36393F]" />
                <Skeleton className="h-5 w-16 bg-[#36393F]" />
              </div>
              <div className="p-4">
                <Skeleton className="h-6 w-32 bg-[#36393F] mb-2" />
                <Skeleton className="h-4 w-24 bg-[#36393F] mb-4" />
                
                <div className="grid grid-cols-2 gap-2 mb-4">
                  {Array(4).fill(0).map((_, i) => (
                    <div key={i} className="bg-[#36393F] rounded p-2">
                      <Skeleton className="h-3 w-12 bg-[#2F3136] mb-1" />
                      <Skeleton className="h-2 w-full bg-[#2F3136]" />
                    </div>
                  ))}
                </div>
                
                <div className="flex space-x-2">
                  <Skeleton className="h-8 flex-1 bg-[#36393F]" />
                  <Skeleton className="h-8 flex-1 bg-[#36393F]" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : selectedView === 'grid' ? (
        // Grid View
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {carList.map((car) => {
            const styles = getRarityStyles(car.rarity);
            const isActive = car.id === userData?.activeCarId;
            
            return (
              <div 
                key={car.id} 
                className={`bg-gradient-to-br from-[#36393F] to-[#2F3136] rounded-lg overflow-hidden ${isActive ? styles.border : 'border border-gray-700'}`}
              >
                <div className={`p-3 ${styles.bgColor} flex justify-between items-center`}>
                  <span className={`${styles.textColor} font-semibold`}>{car.rarity}</span>
                  <div className={`${isActive ? styles.badge : 'bg-[#36393F]'} ${isActive ? styles.badgeText : 'text-[#DCDDDE]'} text-xs font-bold px-2 py-1 rounded`}>
                    {isActive ? 'ACTIVE' : 'GARAGE'}
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="text-white font-semibold text-lg mb-1">{car.name}</h4>
                  <p className="text-[#DCDDDE] text-sm mb-3">{car.type}</p>
                  
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Speed</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-[#5865F2]" style={{ width: `${car.speed}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Acceleration</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-[#57F287]" style={{ width: `${car.acceleration}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Handling</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-[#FEE75C]" style={{ width: `${car.handling}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Boost</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-purple-500" style={{ width: `${car.boost}%` }}></div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    {isActive ? (
                      <Button 
                        className="flex-1 bg-[#57F287] hover:bg-opacity-80 text-white text-sm py-1 rounded"
                        disabled
                      >
                        Active
                      </Button>
                    ) : (
                      <Button 
                        className="flex-1 bg-[#5865F2] hover:bg-opacity-80 text-white text-sm py-1 rounded"
                        onClick={() => handleSetActive(car.id)}
                      >
                        Set Active
                      </Button>
                    )}
                    <Button 
                      variant="outline" 
                      className="flex-1 bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] text-sm py-1 rounded"
                      onClick={() => handleSell(car.id, car.value)}
                    >
                      Sell (₵{car.value.toLocaleString()})
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        // List View
        <div className="mb-6">
          {carList.map((car) => {
            const styles = getRarityStyles(car.rarity);
            const isActive = car.id === userData?.activeCarId;
            
            return (
              <div 
                key={car.id} 
                className={`bg-[#2F3136] rounded-lg overflow-hidden mb-3 ${isActive ? styles.border : 'border border-gray-700'}`}
              >
                <div className="p-3 flex flex-wrap md:flex-nowrap items-center">
                  <div className={`w-12 h-12 ${styles.bgColor} rounded-full flex items-center justify-center mr-3`}>
                    <i className="fas fa-car text-white text-lg"></i>
                  </div>
                  
                  <div className="mr-6 mb-2 md:mb-0">
                    <div className="flex items-center">
                      <h4 className="text-white font-semibold">{car.name}</h4>
                      {isActive && (
                        <span className={`${styles.badge} ${styles.badgeText} text-xs font-bold px-2 py-0.5 rounded ml-2`}>
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-[#DCDDDE]">{car.type} • <span className={styles.textColor}>{car.rarity}</span></p>
                  </div>
                  
                  <div className="flex flex-1 flex-wrap md:flex-nowrap">
                    <div className="flex space-x-3 mr-6 mb-2 md:mb-0">
                      <div>
                        <div className="text-xs text-[#DCDDDE]">Speed</div>
                        <div className="font-medium text-white">{car.speed}</div>
                      </div>
                      <div>
                        <div className="text-xs text-[#DCDDDE]">Accel</div>
                        <div className="font-medium text-white">{car.acceleration}</div>
                      </div>
                      <div>
                        <div className="text-xs text-[#DCDDDE]">Handling</div>
                        <div className="font-medium text-white">{car.handling}</div>
                      </div>
                      <div>
                        <div className="text-xs text-[#DCDDDE]">Boost</div>
                        <div className="font-medium text-white">{car.boost}</div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 ml-auto">
                      {!isActive && (
                        <Button 
                          size="sm"
                          className="bg-[#5865F2] hover:bg-opacity-80 text-white"
                          onClick={() => handleSetActive(car.id)}
                        >
                          Set Active
                        </Button>
                      )}
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE]"
                        onClick={() => handleSell(car.id, car.value)}
                      >
                        Sell (₵{car.value.toLocaleString()})
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
      
      <div className="flex justify-center mt-4">
        <Button 
          variant="outline"
          size="sm"
          className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] px-3 py-1 rounded mr-2 text-sm"
          onClick={prevPage}
          disabled={currentPage === 1}
        >
          <i className="fas fa-chevron-left"></i>
        </Button>
        <span className="bg-[#36393F] text-[#DCDDDE] px-3 py-1 rounded text-sm">
          Page {currentPage} of {totalPages}
        </span>
        <Button 
          variant="outline"
          size="sm"
          className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] px-3 py-1 rounded ml-2 text-sm"
          onClick={nextPage}
          disabled={currentPage === totalPages}
        >
          <i className="fas fa-chevron-right"></i>
        </Button>
      </div>
    </div>
  );
}
