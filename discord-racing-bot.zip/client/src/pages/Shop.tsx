import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShopItem } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Shop() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  
  const { data: shopItems, isLoading } = useQuery<ShopItem[]>({
    queryKey: ['/api/shop'],
    onError: () => {
      toast({
        title: "Error fetching shop items",
        description: "Could not retrieve available cars",
        variant: "destructive"
      });
    }
  });

  const { data: userData } = useQuery({
    queryKey: ['/api/users/1'], // In a real app, this would be the logged-in user's ID
  });

  const purchaseMutation = useMutation({
    mutationFn: (itemId: number) => {
      return apiRequest('POST', `/api/shop/${itemId}/purchase`, { userId: 1 }); // In a real app, this would be the logged-in user's ID
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/1'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/cars'] });
      toast({
        title: "Purchase Successful",
        description: "The car has been added to your garage",
      });
    },
    onError: () => {
      toast({
        title: "Purchase Failed",
        description: "Could not complete the purchase",
        variant: "destructive"
      });
    }
  });

  const handlePurchase = (item: ShopItem) => {
    if (!userData || userData.balance < item.price) {
      toast({
        title: "Insufficient Funds",
        description: `You need ₵${item.price.toLocaleString()} to purchase this car`,
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Confirm Purchase",
      description: `Purchase ${item.name} for ₵${item.price.toLocaleString()}?`,
      action: (
        <Button
          onClick={() => purchaseMutation.mutate(item.id)}
          disabled={purchaseMutation.isPending}
        >
          {purchaseMutation.isPending ? "Processing..." : "Buy Now"}
        </Button>
      ),
    });
  };

  // Helper function for rarity-specific styling
  const getRarityColor = (rarity: string) => {
    switch(rarity) {
      case 'Legendary':
        return { bg: 'from-yellow-500/20 to-yellow-500/5', text: 'text-yellow-300', border: 'border-yellow-500' };
      case 'Epic':
        return { bg: 'from-orange-500/20 to-orange-500/5', text: 'text-orange-400', border: 'border-orange-500' };
      case 'Rare':
        return { bg: 'from-blue-500/20 to-blue-500/5', text: 'text-blue-400', border: 'border-blue-500' };
      case 'Uncommon':
        return { bg: 'from-green-500/20 to-green-500/5', text: 'text-green-400', border: 'border-green-500' };
      case 'Common':
      default:
        return { bg: 'from-green-500/10 to-green-500/5', text: 'text-green-400', border: 'border-gray-700' };
    }
  };

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockShopItems: ShopItem[] = [
    {
      id: 1,
      name: "Bugatti Chiron",
      type: "Hypercar",
      rarity: "Legendary",
      speed: 98,
      acceleration: 93,
      handling: 83,
      boost: 85,
      price: 350000,
      available: true,
      image: "bugatti.svg"
    },
    {
      id: 2,
      name: "McLaren P1",
      type: "Hypercar",
      rarity: "Legendary",
      speed: 95,
      acceleration: 90,
      handling: 85,
      boost: 80,
      price: 250000,
      available: true,
      image: "mclaren.svg"
    },
    {
      id: 3,
      name: "Lamborghini Aventador",
      type: "Supercar",
      rarity: "Epic",
      speed: 92,
      acceleration: 88,
      handling: 80,
      boost: 78,
      price: 150000,
      available: true,
      image: "lambo.svg"
    },
    {
      id: 4,
      name: "Ferrari 488",
      type: "Supercar",
      rarity: "Epic",
      speed: 90,
      acceleration: 85,
      handling: 85,
      boost: 75,
      price: 120000,
      available: true,
      image: "ferrari.svg"
    },
    {
      id: 5,
      name: "Porsche 911",
      type: "Sports",
      rarity: "Rare",
      speed: 85,
      acceleration: 80,
      handling: 90,
      boost: 70,
      price: 60000,
      available: true,
      image: "porsche.svg"
    },
    {
      id: 6,
      name: "Nissan GT-R",
      type: "Sports",
      rarity: "Rare",
      speed: 80,
      acceleration: 85,
      handling: 75,
      boost: 65,
      price: 40000,
      available: true,
      image: "gtr.svg"
    },
    {
      id: 7,
      name: "Toyota Supra",
      type: "Sports",
      rarity: "Uncommon",
      speed: 70,
      acceleration: 75,
      handling: 65,
      boost: 55,
      price: 15000,
      available: true,
      image: "supra.svg"
    },
    {
      id: 8,
      name: "Honda Civic",
      type: "Economy",
      rarity: "Common",
      speed: 55,
      acceleration: 60,
      handling: 70,
      boost: 40,
      price: 5000,
      available: true,
      image: "civic.svg"
    }
  ];

  // Use real data if available, otherwise use mock data for UI demonstration
  const items = shopItems?.length > 0 ? shopItems : mockShopItems;

  // Filter logic
  const filteredItems = items.filter(item => {
    // Filter by search term
    if (searchTerm && !item.name.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Car Shop</h1>
        <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
          <i className="fas fa-coins text-[#FEE75C] mr-2"></i>
          <span className="font-medium">{userData?.balance?.toLocaleString() || '25,750'}</span>
        </div>
      </div>
      
      <Card className="bg-[#2F3136] border-gray-700 mb-6">
        <div className="p-4 flex flex-col sm:flex-row justify-between items-center">
          <div className="w-full sm:w-64 mb-3 sm:mb-0">
            <div className="relative">
              <Input
                className="bg-[#36393F] border-gray-700 text-white pl-10 pr-4 py-2"
                placeholder="Search cars..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <i className="fas fa-search absolute left-3 top-2.5 text-[#DCDDDE]"></i>
            </div>
          </div>
          
          <Tabs defaultValue="all">
            <TabsList className="bg-[#36393F]">
              <TabsTrigger value="all" className="data-[state=active]:bg-[#5865F2]">All</TabsTrigger>
              <TabsTrigger value="legendary" className="data-[state=active]:bg-[#5865F2]">Legendary</TabsTrigger>
              <TabsTrigger value="epic" className="data-[state=active]:bg-[#5865F2]">Epic</TabsTrigger>
              <TabsTrigger value="rare" className="data-[state=active]:bg-[#5865F2]">Rare</TabsTrigger>
              <TabsTrigger value="common" className="data-[state=active]:bg-[#5865F2]">Common</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </Card>
      
      {isLoading ? (
        <div className="text-center py-10">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-[#5865F2] mx-auto"></div>
          <p className="mt-4 text-[#DCDDDE]">Loading cars...</p>
        </div>
      ) : filteredItems.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item) => {
            const colors = getRarityColor(item.rarity);
            const canAfford = userData ? userData.balance >= item.price : true;
            
            return (
              <Card 
                key={item.id} 
                className={`bg-[#2F3136] hover:bg-[#2F3136]/90 transition-all border ${colors.border} overflow-hidden`}
              >
                <div className={`p-3 bg-gradient-to-r ${colors.bg} flex justify-between items-center`}>
                  <span className={`${colors.text} font-semibold`}>{item.rarity}</span>
                  <div className="bg-[#36393F] text-[#DCDDDE] text-xs px-2 py-1 rounded">
                    {item.type}
                  </div>
                </div>
                
                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-white font-semibold text-lg">{item.name}</h3>
                    <div className={`text-${canAfford ? '[#FEE75C]' : '[#ED4245]'} font-bold`}>
                      ₵{item.price.toLocaleString()}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Speed</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-[#5865F2]" style={{ width: `${item.speed}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Acceleration</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-[#57F287]" style={{ width: `${item.acceleration}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Handling</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-[#FEE75C]" style={{ width: `${item.handling}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-[#36393F] rounded p-2">
                      <div className="text-xs text-[#DCDDDE] mb-1">Boost</div>
                      <div className="h-2 bg-gray-700 rounded overflow-hidden">
                        <div className="h-full bg-purple-500" style={{ width: `${item.boost}%` }}></div>
                      </div>
                    </div>
                  </div>
                  
                  <Button 
                    className={`w-full ${canAfford ? 'bg-[#5865F2] hover:bg-opacity-80' : 'bg-[#ED4245] hover:bg-opacity-80'} text-white`}
                    onClick={() => handlePurchase(item)}
                    disabled={!canAfford || purchaseMutation.isPending}
                  >
                    {canAfford ? 'Purchase' : 'Insufficient Funds'}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-10 bg-[#2F3136] rounded-lg">
          <div className="w-16 h-16 mx-auto bg-[#36393F] rounded-full flex items-center justify-center mb-3">
            <i className="fas fa-search text-[#DCDDDE] text-2xl"></i>
          </div>
          <h3 className="text-lg font-medium text-white mb-1">No Cars Found</h3>
          <p className="text-[#DCDDDE]">Try adjusting your search criteria</p>
        </div>
      )}
      
      <div className="mt-8 bg-[#2F3136] rounded-lg p-6">
        <h2 className="text-xl font-semibold text-white mb-4">Car Rarities</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card className="bg-[#36393F] border-yellow-500">
            <div className="p-3 text-center">
              <div className="w-10 h-10 rounded-full bg-yellow-500 mx-auto flex items-center justify-center mb-2">
                <i className="fas fa-star text-black"></i>
              </div>
              <h4 className="text-yellow-300 font-semibold">Legendary</h4>
              <p className="text-xs text-[#DCDDDE] mt-1">90-100 stats</p>
            </div>
          </Card>
          
          <Card className="bg-[#36393F] border-orange-500">
            <div className="p-3 text-center">
              <div className="w-10 h-10 rounded-full bg-orange-500 mx-auto flex items-center justify-center mb-2">
                <i className="fas fa-crown text-white"></i>
              </div>
              <h4 className="text-orange-400 font-semibold">Epic</h4>
              <p className="text-xs text-[#DCDDDE] mt-1">80-90 stats</p>
            </div>
          </Card>
          
          <Card className="bg-[#36393F] border-blue-500">
            <div className="p-3 text-center">
              <div className="w-10 h-10 rounded-full bg-blue-500 mx-auto flex items-center justify-center mb-2">
                <i className="fas fa-gem text-white"></i>
              </div>
              <h4 className="text-blue-400 font-semibold">Rare</h4>
              <p className="text-xs text-[#DCDDDE] mt-1">70-80 stats</p>
            </div>
          </Card>
          
          <Card className="bg-[#36393F] border-green-500">
            <div className="p-3 text-center">
              <div className="w-10 h-10 rounded-full bg-green-500 mx-auto flex items-center justify-center mb-2">
                <i className="fas fa-certificate text-white"></i>
              </div>
              <h4 className="text-green-400 font-semibold">Uncommon</h4>
              <p className="text-xs text-[#DCDDDE] mt-1">60-70 stats</p>
            </div>
          </Card>
          
          <Card className="bg-[#36393F] border-gray-700">
            <div className="p-3 text-center">
              <div className="w-10 h-10 rounded-full bg-gray-600 mx-auto flex items-center justify-center mb-2">
                <i className="fas fa-car text-white"></i>
              </div>
              <h4 className="text-green-400 font-semibold">Common</h4>
              <p className="text-xs text-[#DCDDDE] mt-1">40-60 stats</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
