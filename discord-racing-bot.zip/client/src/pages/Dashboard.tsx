import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { User, Car } from "@/lib/types";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

// Interfaces for dashboard data
interface Transaction {
  id: number;
  userId: number;
  type: string;
  amount: number;
  description: string;
  relatedId?: number;
  timestamp: string;
}

interface ActivityLog {
  id: number;
  type: string;
  userId: number;
  targetId?: number;
  details: Record<string, any>;
  timestamp: string;
}

interface PerformancePart {
  id: number;
  name: string;
  type: string;
  tier: number;
  speedBoost: number;
  accelerationBoost: number;
  handlingBoost: number;
  boostBoost: number;
  price: number;
  description?: string;
}

interface VisualCustomization {
  id: number;
  name: string;
  type: string;
  tier: number;
  price: number;
  description?: string;
  imageUrl?: string;
}

interface CarPart {
  id: number;
  carId: number;
  partId: number;
  installedAt: string;
  details: PerformancePart;
}

interface CarVisual {
  id: number;
  carId: number;
  visualId: number;
  installedAt: string;
  details: VisualCustomization;
}

interface CarCustomization {
  carId: number;
  carName: string;
  parts: CarPart[];
  visuals: CarVisual[];
}

interface DriverSkill {
  id: number;
  userId: number;
  skillType: string;
  level: number;
  experience: number;
}

interface Achievement {
  id: number;
  userId: number;
  achievementId: number;
  unlockedAt: string;
  details?: {
    name: string;
    description: string;
    imageUrl?: string;
  };
}

interface UserChallenge {
  id: number;
  userId: number;
  challengeId: number;
  progress: number;
  target: number;
  completed: boolean;
  details?: {
    name: string;
    description: string;
    reward: number;
  };
}

interface Team {
  id: number;
  name: string;
  description?: string;
  logo?: string;
  createdAt: string;
}

interface TeamMember {
  id: number;
  userId: number;
  teamId: number;
  role: string;
  joinedAt: string;
  username?: string;
}

interface Tournament {
  id: number;
  tournamentId: number;
  userId: number;
  carId: number;
  position?: number;
  status: string;
  joinedAt: string;
  details?: {
    name: string;
    trackType: string;
    prize?: number;
  };
}

interface UserKey {
  id: number;
  userId: number;
  keyType: string;
  quantity: number;
}

interface TrackStat {
  track: string;
  total: number;
  won: number;
  winRate: number;
}

interface DashboardData {
  user: User;
  cars: Car[];
  activeCar: Car | null;
  races: {
    recent: any[];
    stats: {
      total: number;
      won: number;
      lost: number;
      winRate: number;
    };
    trackStats: TrackStat[];
  };
  finances: {
    balance: number;
    earned: number;
    spent: number;
    transactions: Transaction[];
  };
  theft: {
    attempts: number;
    successful: number;
    successRate: number;
  };
  activity: ActivityLog[];
  customizations: {
    cars: CarCustomization[];
    totalParts: number;
    totalVisuals: number;
  };
  skills: {
    driverSkills: DriverSkill[];
    highestSkill: DriverSkill | null;
  };
  achievements: {
    recent: Achievement[];
    progress: {
      completed: number;
      total: number;
      percentage: number;
    };
  };
  challenges: {
    active: UserChallenge[];
    completed: number;
  };
  team: {
    info: Team | null;
    teammates: TeamMember[];
    role: string | null;
  };
  tournaments: {
    active: Tournament[];
    total: number;
  };
  keys: UserKey[];
}

// Helper functions
function formatDate(dateString: string) {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function getRarityColor(rarity: string) {
  switch (rarity) {
    case "Common":
      return "text-gray-300";
    case "Uncommon":
      return "text-green-400";
    case "Rare":
      return "text-blue-400";
    case "Epic":
      return "text-purple-400";
    case "Legendary":
      return "text-orange-400";
    case "Mythic":
      return "text-red-400";
    default:
      return "text-gray-300";
  }
}

function getActivityDisplay(type: string) {
  const activityMap: Record<string, { icon: string; color: string }> = {
    race_won: { icon: "fa-trophy", color: "bg-yellow-500" },
    race_lost: { icon: "fa-flag-checkered", color: "bg-red-500" },
    car_purchased: { icon: "fa-car", color: "bg-blue-500" },
    car_sold: { icon: "fa-dollar-sign", color: "bg-green-500" },
    steal_attempt: { icon: "fa-user-ninja", color: "bg-purple-500" },
    upgrade_purchased: { icon: "fa-wrench", color: "bg-indigo-500" },
    visual_mod_purchased: { icon: "fa-paint-brush", color: "bg-pink-500" },
    achievement_unlocked: { icon: "fa-medal", color: "bg-amber-500" },
  };

  return activityMap[type] || { icon: "fa-history", color: "bg-gray-500" };
}

function getTransactionDisplay(type: string, amount: number) {
  const isPositive = amount > 0;
  const txMap: Record<
    string,
    { color: string; icon: string; prefix: string }
  > = {
    race_winnings: {
      color: "text-green-400",
      icon: "fa-trophy",
      prefix: "+",
    },
    race_bet: {
      color: isPositive ? "text-green-400" : "text-red-400",
      icon: isPositive ? "fa-coins" : "fa-coins",
      prefix: isPositive ? "+" : "-",
    },
    car_purchase: {
      color: "text-red-400",
      icon: "fa-car",
      prefix: "-",
    },
    car_sale: {
      color: "text-green-400",
      icon: "fa-dollar-sign",
      prefix: "+",
    },
    upgrade_purchase: {
      color: "text-red-400",
      icon: "fa-wrench",
      prefix: "-",
    },
    theft: {
      color: isPositive ? "text-green-400" : "text-red-400",
      icon: isPositive ? "fa-user-ninja" : "fa-user-ninja",
      prefix: isPositive ? "+" : "-",
    },
    admin_adjustment: {
      color: isPositive ? "text-green-400" : "text-red-400",
      icon: "fa-user-shield",
      prefix: isPositive ? "+" : "-",
    },
  };

  return (
    txMap[type] || {
      color: isPositive ? "text-green-400" : "text-red-400",
      icon: "fa-exchange-alt",
      prefix: isPositive ? "+" : "-",
    }
  );
}

export default function Dashboard() {
  const { toast } = useToast();
  
  const { data: dashboardData, isLoading, error } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
  });

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-8 w-40" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Skeleton className="h-60" />
          <Skeleton className="h-60" />
          <Skeleton className="h-60" />
        </div>
        
        <Skeleton className="h-80 mb-6" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Skeleton className="h-60" />
          <Skeleton className="h-60" />
        </div>
        
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-6xl mx-auto p-8">
        <div className="bg-[#ED4245] text-white p-4 rounded-md mb-4">
          <h2 className="text-xl font-bold">Error Loading Dashboard</h2>
          <p>There was a problem fetching your dashboard data. Please try again later.</p>
        </div>
        <button 
          onClick={() => window.location.reload()} 
          className="bg-[#5865F2] hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="max-w-6xl mx-auto p-8">
        <div className="bg-[#FAA61A] text-white p-4 rounded-md">
          <h2 className="text-xl font-bold">No Data Available</h2>
          <p>We couldn't find any data for your dashboard. Please make sure you're connected to Discord.</p>
        </div>
      </div>
    );
  }

  const { 
    user, 
    cars, 
    activeCar, 
    races, 
    finances, 
    theft, 
    activity,
    customizations,
    skills,
    achievements,
    challenges,
    team,
    tournaments,
    keys
  } = dashboardData;

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Dashboard</h1>
        <div className="flex space-x-3 mt-2 md:mt-0">
          <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
            <i className="fas fa-coins text-[#FEE75C] mr-2"></i>
            <span className="font-medium">₵{user.balance?.toLocaleString()}</span>
          </div>
          <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
            <i className="fas fa-car-side text-[#DCDDDE] mr-2"></i>
            <span className="font-medium">{cars.length}</span>
          </div>
        </div>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Race Stats */}
        <Card className="bg-[#2F3136] border-gray-700 p-6">
          <h2 className="text-[#DCDDDE] text-sm uppercase font-semibold mb-2">Racing Stats</h2>
          <div className="text-4xl font-bold text-white mb-1">{races.stats.total}</div>
          <p className="text-[#DCDDDE]">Total Races</p>
          
          <div className="mt-4 space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span className="text-[#DCDDDE]">Win Rate</span>
              <span className="text-[#57F287] font-medium">{races.stats.winRate}%</span>
            </div>
            <Progress value={races.stats.winRate} className="h-2 bg-[#36393F]" indicatorClassName="bg-[#57F287]" />
            
            <div className="flex justify-between mt-3">
              <div>
                <div className="text-xs text-[#DCDDDE]">Won</div>
                <div className="text-lg font-semibold text-white">{races.stats.won}</div>
              </div>
              <div>
                <div className="text-xs text-[#DCDDDE]">Lost</div>
                <div className="text-lg font-semibold text-white">{races.stats.lost}</div>
              </div>
            </div>
          </div>
        </Card>
        
        {/* Financial Stats */}
        <Card className="bg-[#2F3136] border-gray-700 p-6">
          <h2 className="text-[#DCDDDE] text-sm uppercase font-semibold mb-2">Finances</h2>
          <div className="text-4xl font-bold text-[#FEE75C] mb-1">₵{finances.balance.toLocaleString()}</div>
          <p className="text-[#DCDDDE]">Current Balance</p>
          
          <div className="mt-4">
            <div className="flex justify-between mt-3">
              <div>
                <div className="text-xs text-[#DCDDDE]">Earned</div>
                <div className="text-lg font-semibold text-[#57F287]">₵{finances.earned.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-xs text-[#DCDDDE]">Spent</div>
                <div className="text-lg font-semibold text-[#ED4245]">₵{finances.spent.toLocaleString()}</div>
              </div>
            </div>
          </div>
        </Card>
        
        {/* Theft Stats */}
        <Card className="bg-[#2F3136] border-gray-700 p-6">
          <h2 className="text-[#DCDDDE] text-sm uppercase font-semibold mb-2">Theft Operations</h2>
          <div className="text-4xl font-bold text-white mb-1">{theft.attempts}</div>
          <p className="text-[#DCDDDE]">Steal Attempts</p>
          
          <div className="mt-4 space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span className="text-[#DCDDDE]">Success Rate</span>
              <span className="text-[#57F287] font-medium">{theft.successRate}%</span>
            </div>
            <Progress value={theft.successRate} className="h-2 bg-[#36393F]" indicatorClassName="bg-[#ED4245]" />
            
            <div className="flex justify-between mt-3">
              <div>
                <div className="text-xs text-[#DCDDDE]">Successful</div>
                <div className="text-lg font-semibold text-white">{theft.successful}</div>
              </div>
              <div>
                <div className="text-xs text-[#DCDDDE]">Failed</div>
                <div className="text-lg font-semibold text-white">{theft.attempts - theft.successful}</div>
              </div>
            </div>
          </div>
        </Card>
      </div>
      
      {/* Active Car */}
      {activeCar && (
        <Card className="bg-[#2F3136] border-gray-700 p-6 mb-6">
          <h2 className="text-xl font-bold text-white mb-4">Active Car</h2>
          <div className="bg-[#36393F] rounded-lg p-4">
            <div className="flex items-center mb-3">
              <div className="w-12 h-12 rounded-full bg-[#5865F2] flex items-center justify-center text-white mr-3">
                <i className="fas fa-car text-xl"></i>
              </div>
              <div>
                <h4 className="text-white font-semibold">{activeCar.name}</h4>
                <p className="text-sm">
                  <span className="text-[#DCDDDE]">{activeCar.type}</span>
                  <span className="mx-2">•</span>
                  <span className={getRarityColor(activeCar.rarity)}>{activeCar.rarity}</span>
                </p>
              </div>
              <div className="ml-auto text-right">
                <div className="text-xs text-[#DCDDDE]">Value</div>
                <div className="text-[#FEE75C]">₵{activeCar.value.toLocaleString()}</div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[#DCDDDE]">Speed</span>
                  <span className="text-white">{activeCar.speed}/100</span>
                </div>
                <div className="h-2 bg-gray-700 rounded overflow-hidden">
                  <div className="h-full bg-[#5865F2]" style={{ width: `${activeCar.speed}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[#DCDDDE]">Acceleration</span>
                  <span className="text-white">{activeCar.acceleration}/100</span>
                </div>
                <div className="h-2 bg-gray-700 rounded overflow-hidden">
                  <div className="h-full bg-[#57F287]" style={{ width: `${activeCar.acceleration}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[#DCDDDE]">Handling</span>
                  <span className="text-white">{activeCar.handling}/100</span>
                </div>
                <div className="h-2 bg-gray-700 rounded overflow-hidden">
                  <div className="h-full bg-[#FEE75C]" style={{ width: `${activeCar.handling}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[#DCDDDE]">Boost</span>
                  <span className="text-white">{activeCar.boost}/100</span>
                </div>
                <div className="h-2 bg-gray-700 rounded overflow-hidden">
                  <div className="h-full bg-purple-500" style={{ width: `${activeCar.boost}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}
      
      {/* Main Dashboard Tabs */}
      <Card className="bg-[#2F3136] border-gray-700 mb-6">
        <Tabs defaultValue="collection" className="w-full">
          <div className="border-b border-gray-700">
            <TabsList className="flex justify-start bg-transparent border-b-0 p-0">
              <TabsTrigger 
                value="collection" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] data-[state=active]:text-white border-b-2 border-transparent rounded-none text-[#DCDDDE] px-4 py-3 bg-transparent"
              >
                Car Collection
              </TabsTrigger>
              <TabsTrigger 
                value="customization" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] data-[state=active]:text-white border-b-2 border-transparent rounded-none text-[#DCDDDE] px-4 py-3 bg-transparent"
              >
                Customization
              </TabsTrigger>
              <TabsTrigger 
                value="skills" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] data-[state=active]:text-white border-b-2 border-transparent rounded-none text-[#DCDDDE] px-4 py-3 bg-transparent"
              >
                Driver Skills
              </TabsTrigger>
              <TabsTrigger 
                value="achievements" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] data-[state=active]:text-white border-b-2 border-transparent rounded-none text-[#DCDDDE] px-4 py-3 bg-transparent"
              >
                Progress
              </TabsTrigger>
              {team.info && (
                <TabsTrigger 
                  value="team" 
                  className="data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] data-[state=active]:text-white border-b-2 border-transparent rounded-none text-[#DCDDDE] px-4 py-3 bg-transparent"
                >
                  Team
                </TabsTrigger>
              )}
            </TabsList>
          </div>
          
          {/* Car Collection Tab */}
          <TabsContent value="collection" className="p-4">
            <div className="mb-4">
              <Tabs defaultValue="all">
                <TabsList className="bg-[#36393F] mb-4">
                  <TabsTrigger value="all" className="data-[state=active]:bg-[#5865F2]">All Cars</TabsTrigger>
                  <TabsTrigger value="rare" className="data-[state=active]:bg-[#5865F2]">Rare & Above</TabsTrigger>
                  <TabsTrigger value="common" className="data-[state=active]:bg-[#5865F2]">Common & Uncommon</TabsTrigger>
                </TabsList>
                
                <TabsContent value="all">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cars.map(car => {
                      const isActive = car.id === user.activeCarId;
                      return (
                        <div key={car.id} className={`bg-[#36393F] rounded-lg p-3 ${isActive ? 'border border-[#5865F2]' : ''}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-white font-medium">{car.name}</h3>
                              <div className="flex items-center">
                                <span className="text-xs text-[#DCDDDE]">{car.type}</span>
                                <span className="mx-1">•</span>
                                <span className={`text-xs ${getRarityColor(car.rarity)}`}>{car.rarity}</span>
                              </div>
                            </div>
                            {isActive && (
                              <span className="bg-[#5865F2] text-white text-xs font-bold px-2 py-1 rounded">ACTIVE</span>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 mt-3">
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Speed</div>
                              <div className="text-white font-medium">{car.speed}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Accel</div>
                              <div className="text-white font-medium">{car.acceleration}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Handling</div>
                              <div className="text-white font-medium">{car.handling}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Boost</div>
                              <div className="text-white font-medium">{car.boost}</div>
                            </div>
                          </div>
                          
                          <div className="mt-3 text-right">
                            <span className="text-xs text-[#DCDDDE]">Value:</span>
                            <span className="text-[#FEE75C] ml-1">₵{car.value.toLocaleString()}</span>
                          </div>
                        </div>
                      );
                    })}
                    
                    {cars.length === 0 && (
                      <div className="col-span-3 text-center py-8">
                        <p className="text-[#DCDDDE]">You don't have any cars yet. Visit the shop to buy your first car!</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="rare">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cars.filter(car => ['Rare', 'Epic', 'Legendary', 'Mythic'].includes(car.rarity)).map(car => {
                      const isActive = car.id === user.activeCarId;
                      return (
                        <div key={car.id} className={`bg-[#36393F] rounded-lg p-3 ${isActive ? 'border border-[#5865F2]' : ''}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-white font-medium">{car.name}</h3>
                              <div className="flex items-center">
                                <span className="text-xs text-[#DCDDDE]">{car.type}</span>
                                <span className="mx-1">•</span>
                                <span className={`text-xs ${getRarityColor(car.rarity)}`}>{car.rarity}</span>
                              </div>
                            </div>
                            {isActive && (
                              <span className="bg-[#5865F2] text-white text-xs font-bold px-2 py-1 rounded">ACTIVE</span>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 mt-3">
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Speed</div>
                              <div className="text-white font-medium">{car.speed}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Accel</div>
                              <div className="text-white font-medium">{car.acceleration}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Handling</div>
                              <div className="text-white font-medium">{car.handling}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Boost</div>
                              <div className="text-white font-medium">{car.boost}</div>
                            </div>
                          </div>
                          
                          <div className="mt-3 text-right">
                            <span className="text-xs text-[#DCDDDE]">Value:</span>
                            <span className="text-[#FEE75C] ml-1">₵{car.value.toLocaleString()}</span>
                          </div>
                        </div>
                      );
                    })}
                    
                    {cars.filter(car => ['Rare', 'Epic', 'Legendary', 'Mythic'].includes(car.rarity)).length === 0 && (
                      <div className="col-span-3 text-center py-8">
                        <p className="text-[#DCDDDE]">No rare or better cars in your collection yet.</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="common">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cars.filter(car => ['Common', 'Uncommon'].includes(car.rarity)).map(car => {
                      const isActive = car.id === user.activeCarId;
                      return (
                        <div key={car.id} className={`bg-[#36393F] rounded-lg p-3 ${isActive ? 'border border-[#5865F2]' : ''}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-white font-medium">{car.name}</h3>
                              <div className="flex items-center">
                                <span className="text-xs text-[#DCDDDE]">{car.type}</span>
                                <span className="mx-1">•</span>
                                <span className={`text-xs ${getRarityColor(car.rarity)}`}>{car.rarity}</span>
                              </div>
                            </div>
                            {isActive && (
                              <span className="bg-[#5865F2] text-white text-xs font-bold px-2 py-1 rounded">ACTIVE</span>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 mt-3">
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Speed</div>
                              <div className="text-white font-medium">{car.speed}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Accel</div>
                              <div className="text-white font-medium">{car.acceleration}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Handling</div>
                              <div className="text-white font-medium">{car.handling}</div>
                            </div>
                            <div className="text-center bg-[#2F3136] rounded p-1">
                              <div className="text-xs text-[#DCDDDE]">Boost</div>
                              <div className="text-white font-medium">{car.boost}</div>
                            </div>
                          </div>
                          
                          <div className="mt-3 text-right">
                            <span className="text-xs text-[#DCDDDE]">Value:</span>
                            <span className="text-[#FEE75C] ml-1">₵{car.value.toLocaleString()}</span>
                          </div>
                        </div>
                      );
                    })}
                    
                    {cars.filter(car => ['Common', 'Uncommon'].includes(car.rarity)).length === 0 && (
                      <div className="col-span-3 text-center py-8">
                        <p className="text-[#DCDDDE]">No common or uncommon cars in your collection.</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            
            {/* Keys section */}
            {keys && keys.length > 0 && (
              <div className="bg-[#36393F] rounded-lg p-4 mt-6">
                <h3 className="text-white font-semibold mb-3">Your Keys</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {keys.map((key, index) => (
                    <div key={index} className="bg-[#2F3136] rounded-lg p-3 text-center">
                      <div className="w-12 h-12 mx-auto bg-[#202225] rounded-full flex items-center justify-center mb-2">
                        <i className="fas fa-key text-[#FEE75C]"></i>
                      </div>
                      <div className="text-white font-medium">{key.keyType.replace('_', ' ')}</div>
                      <div className="text-[#DCDDDE] text-sm">x{key.quantity}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
          
          {/* Customization Tab */}
          <TabsContent value="customization" className="p-4">
            <div className="flex flex-col gap-6">
              <div className="bg-[#36393F] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-4">Customization Progress</h3>
                <div className="flex flex-wrap gap-6 mb-4">
                  <div className="bg-[#2F3136] rounded-lg p-3 text-center min-w-[120px]">
                    <div className="w-12 h-12 mx-auto bg-[#202225] rounded-full flex items-center justify-center mb-2">
                      <i className="fas fa-tools text-[#5865F2]"></i>
                    </div>
                    <div className="text-white font-medium">{customizations?.totalParts || 0}</div>
                    <div className="text-[#DCDDDE] text-sm">Performance Parts</div>
                  </div>
                  <div className="bg-[#2F3136] rounded-lg p-3 text-center min-w-[120px]">
                    <div className="w-12 h-12 mx-auto bg-[#202225] rounded-full flex items-center justify-center mb-2">
                      <i className="fas fa-paint-brush text-[#EB459E]"></i>
                    </div>
                    <div className="text-white font-medium">{customizations?.totalVisuals || 0}</div>
                    <div className="text-[#DCDDDE] text-sm">Visual Mods</div>
                  </div>
                </div>
              </div>
              
              {customizations?.cars && customizations.cars.filter(car => car.parts.length > 0 || car.visuals.length > 0).length > 0 ? (
                <div className="bg-[#36393F] rounded-lg p-4">
                  <h3 className="text-white font-semibold mb-3">Customized Cars</h3>
                  <div className="space-y-4">
                    {customizations.cars
                      .filter(car => car.parts.length > 0 || car.visuals.length > 0)
                      .map((car, index) => (
                        <div key={index} className="bg-[#2F3136] rounded-lg p-3">
                          <div className="text-white font-medium mb-2">{car.carName}</div>
                          
                          {car.parts.length > 0 && (
                            <div className="mb-3">
                              <div className="text-sm text-[#DCDDDE] mb-2">Performance Parts</div>
                              <div className="flex flex-wrap gap-2">
                                {car.parts.map((part, partIndex) => (
                                  <div key={partIndex} className="bg-[#202225] rounded-md px-2 py-1 text-xs">
                                    <span className="text-[#5865F2]">{part.details?.name}</span>
                                    <span className="text-[#DCDDDE] ml-1">T{part.details?.tier}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {car.visuals.length > 0 && (
                            <div>
                              <div className="text-sm text-[#DCDDDE] mb-2">Visual Mods</div>
                              <div className="flex flex-wrap gap-2">
                                {car.visuals.map((visual, visualIndex) => (
                                  <div key={visualIndex} className="bg-[#202225] rounded-md px-2 py-1 text-xs">
                                    <span className="text-[#EB459E]">{visual.details?.name}</span>
                                    <span className="text-[#DCDDDE] ml-1">T{visual.details?.tier}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                  </div>
                </div>
              ) : (
                <div className="bg-[#36393F] rounded-lg p-8 text-center">
                  <div className="w-16 h-16 mx-auto bg-[#2F3136] rounded-full flex items-center justify-center mb-3">
                    <i className="fas fa-tools text-[#DCDDDE] text-xl"></i>
                  </div>
                  <h3 className="text-white font-medium mb-2">No Customizations Yet</h3>
                  <p className="text-[#DCDDDE]">Visit the shop to upgrade your cars with performance parts and visual mods!</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Driver Skills Tab */}
          <TabsContent value="skills" className="p-4">
            <div className="flex flex-col gap-6">
              {skills?.driverSkills && skills.driverSkills.length > 0 ? (
                <div className="bg-[#36393F] rounded-lg p-4">
                  <h3 className="text-white font-semibold mb-4">Driver Skills</h3>
                  <div className="space-y-4">
                    {skills.driverSkills.map((skill, index) => (
                      <div key={index} className="bg-[#2F3136] rounded-lg p-3">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center mr-2">
                              <i className={`fas ${
                                skill.skillType === 'drift' ? 'fa-snowflake' : 
                                skill.skillType === 'drag' ? 'fa-stopwatch' : 
                                skill.skillType === 'circuit' ? 'fa-route' : 
                                'fa-car-side'
                              }`}></i>
                            </div>
                            <div>
                              <div className="text-white font-medium capitalize">{skill.skillType}</div>
                              <div className="text-xs text-[#DCDDDE]">Level {skill.level}</div>
                            </div>
                          </div>
                          <div className="bg-[#5865F2] text-white text-xs font-bold px-2 py-1 rounded">
                            LVL {skill.level}
                          </div>
                        </div>
                        <div className="mt-2">
                          <div className="flex justify-between text-xs text-[#DCDDDE] mb-1">
                            <span>Experience</span>
                            <span>{skill.experience} / {skill.level * 1000}</span>
                          </div>
                          <div className="h-2 bg-[#202225] rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-[#5865F2]" 
                              style={{ width: `${Math.min(100, (skill.experience / (skill.level * 1000)) * 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="bg-[#36393F] rounded-lg p-8 text-center">
                  <div className="w-16 h-16 mx-auto bg-[#2F3136] rounded-full flex items-center justify-center mb-3">
                    <i className="fas fa-tachometer-alt text-[#DCDDDE] text-xl"></i>
                  </div>
                  <h3 className="text-white font-medium mb-2">No Driver Skills Yet</h3>
                  <p className="text-[#DCDDDE]">Race in different track types to develop your driver skills!</p>
                </div>
              )}
              
              {races?.trackStats && races.trackStats.length > 0 && (
                <div className="bg-[#36393F] rounded-lg p-4">
                  <h3 className="text-white font-semibold mb-4">Track Performance</h3>
                  <div className="space-y-4">
                    {races.trackStats.map((track, index) => (
                      <div key={index} className="bg-[#2F3136] rounded-lg p-3">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="text-white font-medium capitalize">{track.track.replace(/_/g, ' ')}</div>
                            <div className="text-xs text-[#DCDDDE]">{track.total} races • {track.won} wins</div>
                          </div>
                          <div className="text-[#57F287] font-semibold">{track.winRate}%</div>
                        </div>
                        <div className="mt-2">
                          <div className="h-2 bg-[#202225] rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-[#57F287]" 
                              style={{ width: `${track.winRate}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Achievements & Challenges Tab */}
          <TabsContent value="achievements" className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Achievements Section */}
              <div className="bg-[#36393F] rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-white font-semibold">Achievements</h3>
                  <div className="text-sm text-[#DCDDDE]">
                    {achievements?.progress?.completed || 0}/{achievements?.progress?.total || 0}
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-[#DCDDDE] mb-1">
                    <span>Progress</span>
                    <span>{achievements?.progress?.percentage || 0}%</span>
                  </div>
                  <Progress 
                    value={achievements?.progress?.percentage || 0} 
                    className="h-2 bg-[#202225]" 
                    indicatorClassName="bg-[#5865F2]" 
                  />
                </div>
                
                {achievements?.recent && achievements.recent.length > 0 ? (
                  <div className="space-y-3 mt-5">
                    {achievements.recent.map((achievement, index) => (
                      <div key={index} className="bg-[#2F3136] rounded-lg p-3 flex items-start">
                        <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center mr-3 flex-shrink-0">
                          <i className="fas fa-trophy text-yellow-400"></i>
                        </div>
                        <div>
                          <div className="text-white font-medium">
                            {achievement.details?.name || `Achievement #${achievement.achievementId}`}
                          </div>
                          <p className="text-sm text-[#DCDDDE]">
                            {achievement.details?.description || "You've unlocked this achievement!"}
                          </p>
                          <p className="text-xs text-[#4F545C] mt-1">{formatDate(achievement.unlockedAt)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-[#DCDDDE]">
                    <p>No achievements unlocked yet. Keep racing to earn achievements!</p>
                  </div>
                )}
              </div>
              
              {/* Challenges Section */}
              <div className="bg-[#36393F] rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-white font-semibold">Daily Challenges</h3>
                  <div className="bg-[#5865F2] text-white text-xs px-2 py-1 rounded-full">
                    {challenges?.active?.length || 0} Active
                  </div>
                </div>
                
                {challenges?.active && challenges.active.length > 0 ? (
                  <div className="space-y-4">
                    {challenges.active.map((challenge, index) => (
                      <div key={index} className="bg-[#2F3136] rounded-lg p-3">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="text-white font-medium">
                              {challenge.details?.name || `Challenge #${challenge.challengeId}`}
                            </div>
                            <p className="text-sm text-[#DCDDDE]">
                              {challenge.details?.description || "Complete this challenge to earn rewards"}
                            </p>
                          </div>
                          <div className="text-[#FEE75C] text-sm font-medium">
                            +₵{challenge.details?.reward || 1000}
                          </div>
                        </div>
                        
                        <div className="mt-3">
                          <div className="flex justify-between text-xs text-[#DCDDDE] mb-1">
                            <span>Progress</span>
                            <span>{challenge.progress}/{challenge.target}</span>
                          </div>
                          <Progress 
                            value={(challenge.progress / challenge.target) * 100} 
                            className="h-2 bg-[#202225]" 
                            indicatorClassName="bg-[#57F287]"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-[#DCDDDE]">
                    <p>No active challenges. Check back tomorrow for new daily challenges!</p>
                  </div>
                )}
                
                {challenges?.completed > 0 && (
                  <div className="mt-6 p-3 bg-[#2F3136] rounded-lg text-center">
                    <div className="text-[#DCDDDE]">Completed Challenges</div>
                    <div className="text-white text-2xl font-bold">{challenges.completed}</div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          {/* Team Tab */}
          {team?.info && (
            <TabsContent value="team" className="p-4">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="bg-[#36393F] rounded-lg p-4 md:w-1/2">
                  <div className="flex items-center mb-4">
                    <div className="w-16 h-16 bg-[#5865F2] rounded-full flex items-center justify-center mr-4 text-2xl text-white">
                      {team.info.logo ? (
                        <img src={team.info.logo} alt={team.info.name} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        <i className="fas fa-users"></i>
                      )}
                    </div>
                    <div>
                      <h3 className="text-white text-xl font-bold">{team.info.name}</h3>
                      <p className="text-[#DCDDDE]">Member since {formatDate(team.info.createdAt)}</p>
                      <div className="mt-1 bg-[#5865F2] text-white text-xs px-2 py-1 rounded inline-block capitalize">
                        {team.role || 'Member'}
                      </div>
                    </div>
                  </div>
                  
                  {team.info.description && (
                    <div className="bg-[#2F3136] rounded-lg p-3">
                      <h4 className="text-white font-medium mb-2">Team Description</h4>
                      <p className="text-[#DCDDDE] text-sm">{team.info.description}</p>
                    </div>
                  )}
                </div>
                
                <div className="bg-[#36393F] rounded-lg p-4 md:w-1/2">
                  <h3 className="text-white font-semibold mb-3">Team Members</h3>
                  
                  {team.teammates && team.teammates.length > 0 ? (
                    <div className="space-y-2">
                      {team.teammates.map((member, index) => (
                        <div key={index} className="bg-[#2F3136] rounded-lg p-2 flex items-center">
                          <div className="w-8 h-8 rounded-full bg-[#202225] flex items-center justify-center mr-2">
                            <i className="fas fa-user text-[#DCDDDE]"></i>
                          </div>
                          <div>
                            <div className="text-white text-sm">{member.username || `User #${member.userId}`}</div>
                            <div className="text-xs text-[#DCDDDE] capitalize">{member.role}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-[#DCDDDE]">
                      <p>You're the only member in this team. Invite others to join your crew!</p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </Card>
      
      {/* Detailed information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Recent Activity */}
        <Card className="bg-[#2F3136] border-gray-700">
          <div className="p-4 border-b border-gray-700">
            <h2 className="text-xl font-bold text-white">Recent Activity</h2>
          </div>
          <div className="p-4">
            {activity && activity.length > 0 ? (
              <div className="space-y-4">
                {activity.map((log, index) => {
                  const { icon, color } = getActivityDisplay(log.type);
                  return (
                    <div key={index} className="flex items-start">
                      <div className={`${color} w-10 h-10 rounded-full flex items-center justify-center text-white mr-3 flex-shrink-0`}>
                        <i className={`fas ${icon}`}></i>
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium">{log.type.replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase())}</p>
                        <p className="text-sm text-[#DCDDDE]">
                          {log.details && typeof log.details === 'object' && Object.entries(log.details)
                            .filter(([key]) => key !== 'details' && key !== 'type')
                            .map(([key, value]) => {
                              if (key === 'carName') return `${value}`;
                              if (key === 'rarity') return <span className={getRarityColor(value as string)}>{value}</span>;
                              if (key === 'price' || key === 'winnings' || key === 'bet') return `₵${Number(value).toLocaleString()}`;
                              return `${key}: ${value}`;
                            })
                            .filter(Boolean)
                            .join(' • ')}
                        </p>
                        <p className="text-xs text-[#4F545C] mt-1">{formatDate(log.timestamp)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-[#DCDDDE] text-center py-4">No recent activity</p>
            )}
          </div>
        </Card>
        
        {/* Recent Transactions */}
        <Card className="bg-[#2F3136] border-gray-700">
          <div className="p-4 border-b border-gray-700">
            <h2 className="text-xl font-bold text-white">Recent Transactions</h2>
          </div>
          <div className="p-4">
            {finances.transactions && finances.transactions.length > 0 ? (
              <div className="space-y-4">
                {finances.transactions.map((tx, index) => {
                  const { color, icon, prefix } = getTransactionDisplay(tx.type, tx.amount);
                  return (
                    <div key={index} className="flex items-center justify-between bg-[#36393F] rounded-lg p-3">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-[#2F3136] flex items-center justify-center mr-3">
                          <i className={`fas ${icon} ${color}`}></i>
                        </div>
                        <div>
                          <p className="text-white font-medium">{tx.type.replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase())}</p>
                          <p className="text-xs text-[#DCDDDE]">{tx.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${color}`}>{prefix}₵{Math.abs(tx.amount).toLocaleString()}</p>
                        <p className="text-xs text-[#4F545C]">{formatDate(tx.timestamp)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-[#DCDDDE] text-center py-4">No recent transactions</p>
            )}
          </div>
        </Card>
      </div>
      
      {/* Tournaments Section */}
      {tournaments?.active && tournaments.active.length > 0 && (
        <Card className="bg-[#2F3136] border-gray-700 mb-6">
          <div className="p-4 border-b border-gray-700">
            <h2 className="text-xl font-bold text-white">Active Tournaments</h2>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tournaments.active.map((tournament, index) => (
                <div key={index} className="bg-[#36393F] rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="text-white font-semibold">
                        {tournament.details?.name || `Tournament #${tournament.tournamentId}`}
                      </h3>
                      <p className="text-sm text-[#DCDDDE]">
                        {tournament.details?.trackType || "Unknown Track"}
                      </p>
                    </div>
                    <div className="bg-[#5865F2] px-2 py-1 rounded text-white text-xs font-bold">
                      {tournament.status || "ACTIVE"}
                    </div>
                  </div>
                  
                  <div className="text-[#DCDDDE] text-sm mb-3">
                    Car: {cars.find(c => c.id === tournament.carId)?.name || `Car #${tournament.carId}`}
                  </div>
                  
                  {tournament.position ? (
                    <div className="flex items-center justify-between">
                      <div className="text-white">Current Position:</div>
                      <div className="font-bold text-xl text-[#FEE75C]">#{tournament.position}</div>
                    </div>
                  ) : (
                    <div className="text-[#DCDDDE] text-sm italic">
                      Position not yet determined
                    </div>
                  )}
                  
                  {tournament.details?.prize && (
                    <div className="mt-3 text-right">
                      <span className="text-xs text-[#DCDDDE]">Prize Pool:</span>
                      <span className="text-[#FEE75C] ml-1">₵{tournament.details.prize.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}