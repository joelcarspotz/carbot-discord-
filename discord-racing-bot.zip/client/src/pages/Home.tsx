import { CommandList } from "@/components/CommandList";
import { GarageDisplay } from "@/components/GarageDisplay";
import { ActiveRacesList } from "@/components/ActiveRacesList";
import { RecentActivity } from "@/components/RecentActivity";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Home() {
  return (
    <div>
      <CommandList />
      
      {/* Featured content tabs */}
      <div className="mb-8">
        <Tabs defaultValue="garage">
          <div className="flex border-b border-gray-700 mb-4">
            <TabsList className="bg-transparent">
              <TabsTrigger 
                value="garage" 
                className="px-4 py-2 font-medium data-[state=active]:text-white data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] text-[#DCDDDE] hover:text-white data-[state=active]:shadow-none"
              >
                Garage
              </TabsTrigger>
              <TabsTrigger 
                value="marketplace" 
                className="px-4 py-2 font-medium data-[state=active]:text-white data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] text-[#DCDDDE] hover:text-white data-[state=active]:shadow-none"
              >
                Marketplace
              </TabsTrigger>
              <TabsTrigger 
                value="leaderboard" 
                className="px-4 py-2 font-medium data-[state=active]:text-white data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] text-[#DCDDDE] hover:text-white data-[state=active]:shadow-none"
              >
                Leaderboard
              </TabsTrigger>
              <TabsTrigger 
                value="daily-races" 
                className="px-4 py-2 font-medium data-[state=active]:text-white data-[state=active]:border-b-2 data-[state=active]:border-[#5865F2] text-[#DCDDDE] hover:text-white data-[state=active]:shadow-none"
              >
                Daily Races
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="garage">
            <GarageDisplay />
          </TabsContent>
          
          <TabsContent value="marketplace">
            <div className="bg-[#2F3136] rounded-lg p-6 text-center">
              <h3 className="text-xl font-semibold text-white mb-4">Marketplace</h3>
              <p className="text-[#DCDDDE]">Browse user listings and trade cars with other players.</p>
              <div className="mt-4">
                <p className="text-sm text-[#4F545C]">Coming soon! Check back later.</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="leaderboard">
            <div className="bg-[#2F3136] rounded-lg p-6 text-center">
              <h3 className="text-xl font-semibold text-white mb-4">Leaderboard</h3>
              <p className="text-[#DCDDDE]">See the top racers and car collectors.</p>
              <div className="mt-4">
                <p className="text-sm text-[#4F545C]">Coming soon! Check back later.</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="daily-races">
            <div className="bg-[#2F3136] rounded-lg p-6 text-center">
              <h3 className="text-xl font-semibold text-white mb-4">Daily Races</h3>
              <p className="text-[#DCDDDE]">Participate in special daily events for bonus rewards.</p>
              <div className="mt-4">
                <p className="text-sm text-[#4F545C]">Coming soon! Check back later.</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <ActiveRacesList />
      
      <RecentActivity />
    </div>
  );
}
