import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RaceModal } from "@/components/RaceModal";
import { Race as RaceType } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function Race() {
  const { toast } = useToast();
  
  const { data: activeRaces, isLoading: isLoadingRaces } = useQuery<RaceType[]>({
    queryKey: ['/api/races'],
    onError: () => {
      toast({
        title: "Error fetching races",
        description: "Could not retrieve active races",
        variant: "destructive"
      });
    }
  });

  const { data: user } = useQuery({
    queryKey: ['/api/users/1'], // In a real app, this would be the logged-in user's ID
  });
  
  const { data: userRaces } = useQuery<RaceType[]>({
    queryKey: ['/api/users/1/races'], // In a real app, this would use the actual user ID
  });

  const handleJoinRace = (raceId: number) => {
    toast({
      title: "Join Race",
      description: `You're about to join race #${raceId}`,
      action: (
        <Button
          onClick={() => {
            toast({
              title: "Race joined",
              description: "You've joined the race. Good luck!",
            });
          }}
        >
          Confirm
        </Button>
      ),
    });
  };

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockRaces: Partial<RaceType>[] = [
    {
      id: 1,
      challenger: 2,
      bet: 10000,
      trackType: "street",
      status: "pending",
      createdAt: new Date().toISOString()
    },
    {
      id: 2,
      challenger: 3,
      bet: 5000,
      trackType: "circuit",
      status: "pending",
      createdAt: new Date().toISOString()
    },
    {
      id: 3,
      challenger: 4,
      bet: 15000,
      trackType: "drag",
      status: "pending",
      createdAt: new Date().toISOString()
    }
  ];

  const mockCompletedRaces: Partial<RaceType>[] = [
    {
      id: 101,
      challenger: 1,
      opponent: 5,
      bet: 8000,
      trackType: "street",
      status: "completed",
      winner: 1,
      createdAt: new Date(Date.now() - 3600000).toISOString(),
      completedAt: new Date(Date.now() - 3590000).toISOString()
    },
    {
      id: 102,
      challenger: 6,
      opponent: 1,
      bet: 12000,
      trackType: "drag",
      status: "completed",
      winner: 6,
      createdAt: new Date(Date.now() - 7200000).toISOString(),
      completedAt: new Date(Date.now() - 7190000).toISOString()
    }
  ];

  // Use real data if available, otherwise use mock data for UI demonstration
  const pendingRaces = activeRaces?.filter(race => race.status === 'pending') || mockRaces;
  const raceHistory = userRaces?.filter(race => race.status === 'completed') || mockCompletedRaces;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Race Arena</h1>
        <div className="flex space-x-3">
          <div className="bg-[#36393F] rounded-md px-3 py-1 flex items-center">
            <i className="fas fa-coins text-[#FEE75C] mr-2"></i>
            <span className="font-medium">{user?.balance?.toLocaleString() || '25,750'}</span>
          </div>
          <RaceModal trigger={
            <Button 
              className="bg-[#5865F2] hover:bg-opacity-80 text-white px-3 py-1 rounded-md text-sm"
            >
              <i className="fas fa-plus mr-1"></i> New Race
            </Button>
          } />
        </div>
      </div>
      
      <Tabs defaultValue="active" className="mb-6">
        <div className="bg-[#2F3136] rounded-lg p-4">
          <TabsList className="bg-[#36393F]">
            <TabsTrigger value="active" className="data-[state=active]:bg-[#5865F2]">Active Races</TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-[#5865F2]">Race History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="active" className="mt-4">
            {isLoadingRaces ? (
              <div className="text-center py-6">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2] mx-auto"></div>
                <p className="mt-2 text-[#DCDDDE]">Loading races...</p>
              </div>
            ) : pendingRaces.length > 0 ? (
              <div className="space-y-4">
                {pendingRaces.map((race) => (
                  <Card key={race.id} className="bg-[#36393F] border-none p-4">
                    <div className="flex flex-col md:flex-row justify-between items-center">
                      <div className="flex items-center mb-4 md:mb-0">
                        <div className="w-12 h-12 bg-[#5865F2] rounded-full flex items-center justify-center text-white mr-3">
                          <i className="fas fa-user text-xl"></i>
                        </div>
                        <div>
                          <h4 className="text-white font-medium">@RacingKing</h4>
                          <p className="text-sm text-[#DCDDDE]">Waiting for challenger</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center mb-4 md:mb-0">
                        <div className="px-3 py-1 bg-[#2F3136] rounded text-[#FEE75C] text-sm mr-4">
                          <i className="fas fa-coins mr-1"></i> ₵{race.bet?.toLocaleString() ?? 0} Bet
                        </div>
                        <div className="px-3 py-1 bg-[#2F3136] rounded text-[#DCDDDE] text-sm">
                          <i className="fas fa-map mr-1"></i> {race.trackType}
                        </div>
                      </div>
                      
                      <Button 
                        className="bg-[#5865F2] hover:bg-opacity-80 text-white px-4 py-2 rounded w-full md:w-auto"
                        onClick={() => handleJoinRace(race.id!)}
                      >
                        Join Race
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <div className="w-16 h-16 mx-auto bg-[#36393F] rounded-full flex items-center justify-center mb-3">
                  <i className="fas fa-flag-checkered text-[#DCDDDE] text-2xl"></i>
                </div>
                <h3 className="text-lg font-medium text-white mb-1">No Active Races</h3>
                <p className="text-[#DCDDDE] mb-4">Be the first to create a race challenge!</p>
                <RaceModal />
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="history" className="mt-4">
            {raceHistory.length > 0 ? (
              <div className="space-y-4">
                {raceHistory.map((race) => {
                  const userWon = race.winner === 1; // In a real app, compare with logged-in user ID
                  
                  return (
                    <Card key={race.id} className="bg-[#36393F] border-none p-4">
                      <div className="flex flex-col md:flex-row justify-between items-center">
                        <div className="flex items-center mb-4 md:mb-0">
                          <div className={`w-12 h-12 ${userWon ? 'bg-[#57F287]' : 'bg-[#ED4245]'} rounded-full flex items-center justify-center text-white mr-3`}>
                            <i className={`fas ${userWon ? 'fa-trophy' : 'fa-times'} text-xl`}></i>
                          </div>
                          <div>
                            <div className="flex items-center">
                              <h4 className="text-white font-medium">Race #{race.id}</h4>
                              <span className={`ml-2 text-xs px-2 py-0.5 rounded ${userWon ? 'bg-[#57F287] bg-opacity-20 text-[#57F287]' : 'bg-[#ED4245] bg-opacity-20 text-[#ED4245]'}`}>
                                {userWon ? 'WIN' : 'LOSS'}
                              </span>
                            </div>
                            <p className="text-sm text-[#DCDDDE]">vs @{userWon ? 'Opponent' : 'Winner'}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center mb-4 md:mb-0">
                          <div className="px-3 py-1 bg-[#2F3136] rounded text-[#FEE75C] text-sm mr-4">
                            <i className="fas fa-coins mr-1"></i> ₵{race.bet?.toLocaleString() ?? 0} {userWon ? 'Won' : 'Lost'}
                          </div>
                          <div className="px-3 py-1 bg-[#2F3136] rounded text-[#DCDDDE] text-sm">
                            <i className="fas fa-calendar-alt mr-1"></i> {new Date(race.completedAt || '').toLocaleDateString()}
                          </div>
                        </div>
                        
                        <Button 
                          variant="outline"
                          className="bg-[#2F3136] hover:bg-[#4F545C] text-[#DCDDDE] px-4 py-2 rounded w-full md:w-auto"
                          onClick={() => {
                            toast({
                              title: "Race Details",
                              description: `Details for race #${race.id}`,
                            });
                          }}
                        >
                          View Details
                        </Button>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-10">
                <div className="w-16 h-16 mx-auto bg-[#36393F] rounded-full flex items-center justify-center mb-3">
                  <i className="fas fa-history text-[#DCDDDE] text-2xl"></i>
                </div>
                <h3 className="text-lg font-medium text-white mb-1">No Race History</h3>
                <p className="text-[#DCDDDE] mb-4">Join or create a race to get started!</p>
                <RaceModal />
              </div>
            )}
          </TabsContent>
        </div>
      </Tabs>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-[#2F3136] border-gray-700 p-6">
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
            <i className="fas fa-info-circle text-[#5865F2] mr-2"></i> 
            Race Rules
          </h2>
          <ul className="space-y-3 text-[#DCDDDE]">
            <li className="flex items-start">
              <i className="fas fa-check text-[#57F287] mt-1 mr-2"></i>
              <span>Races require an active car to be set in your garage.</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check text-[#57F287] mt-1 mr-2"></i>
              <span>Both racers must have the bet amount in their balance.</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check text-[#57F287] mt-1 mr-2"></i>
              <span>Race results depend on car stats and track type.</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check text-[#57F287] mt-1 mr-2"></i>
              <span>Winner takes the entire bet amount from both players.</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check text-[#57F287] mt-1 mr-2"></i>
              <span>Races expire after 10 minutes if not accepted.</span>
            </li>
          </ul>
        </Card>
        
        <Card className="bg-[#2F3136] border-gray-700 p-6">
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
            <i className="fas fa-star text-[#FEE75C] mr-2"></i> 
            Track Types
          </h2>
          <div className="space-y-3">
            <div>
              <h3 className="text-white font-medium">Street Race</h3>
              <p className="text-sm text-[#DCDDDE]">Balanced - speed and acceleration focused</p>
            </div>
            <div>
              <h3 className="text-white font-medium">Drag Race</h3>
              <p className="text-sm text-[#DCDDDE]">Speed and acceleration are key</p>
            </div>
            <div>
              <h3 className="text-white font-medium">Circuit</h3>
              <p className="text-sm text-[#DCDDDE]">Emphasizes handling and balanced stats</p>
            </div>
            <div>
              <h3 className="text-white font-medium">Off-road</h3>
              <p className="text-sm text-[#DCDDDE]">Handling and boost are most important</p>
            </div>
            <div>
              <h3 className="text-white font-medium">Drift</h3>
              <p className="text-sm text-[#DCDDDE]">Heavily favors handling capability</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
