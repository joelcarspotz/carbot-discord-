import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Help() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const handleFeedback = () => {
    toast({
      title: "Feedback Sent",
      description: "Thank you for your feedback!",
    });
  };

  // Filter commands based on search term
  const filterCommands = (commands: any[]) => {
    if (!searchTerm) return commands;
    return commands.filter(cmd => 
      cmd.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      cmd.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // Command categories
  const generalCommands = [
    { name: "!help", description: "Display commands and information", usage: "!help [command]", example: "!help race" },
    { name: "!profile", description: "View your driver profile", usage: "!profile [@user]", example: "!profile @RacingKing" },
    { name: "!register", description: "Register to start playing", usage: "!register", example: "!register" },
    { name: "!balance", description: "Check your current balance", usage: "!balance [@user]", example: "!balance" },
    { name: "!daily", description: "Collect daily reward", usage: "!daily", example: "!daily" },
  ];

  const carCommands = [
    { name: "!garage", description: "View your car collection", usage: "!garage [page]", example: "!garage 2" },
    { name: "!car", description: "View details about a specific car", usage: "!car <car_id>", example: "!car 3" },
    { name: "!setactive", description: "Set your active car for racing", usage: "!setactive <car_id>", example: "!setactive 2" },
    { name: "!sell", description: "Sell one of your cars", usage: "!sell <car_id>", example: "!sell 1" },
  ];

  const raceCommands = [
    { name: "!race", description: "Challenge another player to a race", usage: "!race @user <bet> [track_type]", example: "!race @SpeedDemon 5000 circuit" },
    { name: "!join", description: "Join an open race", usage: "!join <race_id>", example: "!join 42" },
    { name: "!races", description: "View active races", usage: "!races", example: "!races" },
  ];

  const shopCommands = [
    { name: "!shop", description: "Browse available cars to purchase", usage: "!shop [category]", example: "!shop legendary" },
    { name: "!buy", description: "Purchase a car from the shop", usage: "!buy <car_id>", example: "!buy 5" },
  ];

  const otherCommands = [
    { name: "!steal", description: "Attempt to steal a car from another user", usage: "!steal @user", example: "!steal @CarCollector" },
    { name: "!leaderboard", description: "View the top players by wealth or races", usage: "!leaderboard [wealth|races]", example: "!leaderboard races" },
  ];

  // Render a command section
  const renderCommandSection = (commands: any[], icon: string, color: string) => {
    const filteredCommands = filterCommands(commands);
    
    if (filteredCommands.length === 0) return null;
    
    return (
      <div className="mb-6">
        {filteredCommands.map((cmd) => (
          <div key={cmd.name} className="bg-[#2F3136] rounded-lg p-4 mb-2">
            <div className="flex items-start">
              <div className={`w-10 h-10 rounded-full ${color} flex items-center justify-center mr-3 flex-shrink-0`}>
                <i className={`fas ${icon} text-white`}></i>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="text-white font-semibold">{cmd.name}</h3>
                  <span className="text-xs bg-[#36393F] px-2 py-1 rounded text-[#DCDDDE]">
                    {cmd.usage}
                  </span>
                </div>
                <p className="text-[#DCDDDE] text-sm mb-2">{cmd.description}</p>
                <div className="bg-[#36393F] rounded p-2 text-sm">
                  <span className="text-[#5865F2]">Example:</span> <span className="text-[#DCDDDE]">{cmd.example}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Help Center</h1>
        <div className="flex space-x-3">
          <Button 
            variant="outline"
            className="bg-[#36393F] border-none hover:bg-[#4F545C] text-[#DCDDDE]"
            onClick={() => window.open("https://discord.gg/trackbyte", "_blank")}
          >
            <i className="fab fa-discord mr-2"></i> Join Discord
          </Button>
        </div>
      </div>
      
      <Card className="bg-[#2F3136] border-gray-700 mb-6">
        <div className="p-4">
          <div className="w-full">
            <div className="relative">
              <Input
                className="bg-[#36393F] border-gray-700 text-white pl-10 pr-4 py-2"
                placeholder="Search commands..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <i className="fas fa-search absolute left-3 top-2.5 text-[#DCDDDE]"></i>
            </div>
          </div>
        </div>
      </Card>
      
      <Tabs defaultValue="commands" className="mb-6">
        <div className="bg-[#2F3136] rounded-lg p-4">
          <TabsList className="bg-[#36393F]">
            <TabsTrigger value="commands" className="data-[state=active]:bg-[#5865F2]">Commands</TabsTrigger>
            <TabsTrigger value="faq" className="data-[state=active]:bg-[#5865F2]">FAQ</TabsTrigger>
            <TabsTrigger value="shortcuts" className="data-[state=active]:bg-[#5865F2]">Shortcuts</TabsTrigger>
          </TabsList>
          
          <TabsContent value="commands" className="mt-4">
            {searchTerm && (
              <div className="mb-4 text-[#DCDDDE]">
                Search results for: <span className="text-white font-medium">"{searchTerm}"</span>
              </div>
            )}
            
            {!searchTerm && (
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6 text-center">
                <Card className="bg-[#36393F] border-gray-700 p-3">
                  <div className="w-10 h-10 rounded-full bg-[#5865F2] mx-auto flex items-center justify-center mb-2">
                    <i className="fas fa-question text-white"></i>
                  </div>
                  <h3 className="text-white font-medium">General</h3>
                  <p className="text-xs text-[#DCDDDE]">{generalCommands.length} commands</p>
                </Card>
                
                <Card className="bg-[#36393F] border-gray-700 p-3">
                  <div className="w-10 h-10 rounded-full bg-[#57F287] mx-auto flex items-center justify-center mb-2">
                    <i className="fas fa-car text-white"></i>
                  </div>
                  <h3 className="text-white font-medium">Cars</h3>
                  <p className="text-xs text-[#DCDDDE]">{carCommands.length} commands</p>
                </Card>
                
                <Card className="bg-[#36393F] border-gray-700 p-3">
                  <div className="w-10 h-10 rounded-full bg-[#FEE75C] mx-auto flex items-center justify-center mb-2">
                    <i className="fas fa-flag-checkered text-black"></i>
                  </div>
                  <h3 className="text-white font-medium">Racing</h3>
                  <p className="text-xs text-[#DCDDDE]">{raceCommands.length} commands</p>
                </Card>
                
                <Card className="bg-[#36393F] border-gray-700 p-3">
                  <div className="w-10 h-10 rounded-full bg-[#5865F2] mx-auto flex items-center justify-center mb-2">
                    <i className="fas fa-store text-white"></i>
                  </div>
                  <h3 className="text-white font-medium">Shop</h3>
                  <p className="text-xs text-[#DCDDDE]">{shopCommands.length} commands</p>
                </Card>
                
                <Card className="bg-[#36393F] border-gray-700 p-3">
                  <div className="w-10 h-10 rounded-full bg-[#ED4245] mx-auto flex items-center justify-center mb-2">
                    <i className="fas fa-key text-white"></i>
                  </div>
                  <h3 className="text-white font-medium">Other</h3>
                  <p className="text-xs text-[#DCDDDE]">{otherCommands.length} commands</p>
                </Card>
              </div>
            )}
            
            {(!searchTerm || filterCommands(generalCommands).length > 0) && (
              <div className="mb-6">
                <h2 className="text-white font-bold text-lg mb-2 flex items-center">
                  <i className="fas fa-question text-[#5865F2] mr-2"></i> General Commands
                </h2>
                {renderCommandSection(generalCommands, "fa-question", "bg-[#5865F2]")}
              </div>
            )}
            
            {(!searchTerm || filterCommands(carCommands).length > 0) && (
              <div className="mb-6">
                <h2 className="text-white font-bold text-lg mb-2 flex items-center">
                  <i className="fas fa-car text-[#57F287] mr-2"></i> Car Commands
                </h2>
                {renderCommandSection(carCommands, "fa-car", "bg-[#57F287]")}
              </div>
            )}
            
            {(!searchTerm || filterCommands(raceCommands).length > 0) && (
              <div className="mb-6">
                <h2 className="text-white font-bold text-lg mb-2 flex items-center">
                  <i className="fas fa-flag-checkered text-[#FEE75C] mr-2"></i> Racing Commands
                </h2>
                {renderCommandSection(raceCommands, "fa-flag-checkered", "bg-[#FEE75C]")}
              </div>
            )}
            
            {(!searchTerm || filterCommands(shopCommands).length > 0) && (
              <div className="mb-6">
                <h2 className="text-white font-bold text-lg mb-2 flex items-center">
                  <i className="fas fa-store text-[#5865F2] mr-2"></i> Shop Commands
                </h2>
                {renderCommandSection(shopCommands, "fa-store", "bg-[#5865F2]")}
              </div>
            )}
            
            {(!searchTerm || filterCommands(otherCommands).length > 0) && (
              <div className="mb-6">
                <h2 className="text-white font-bold text-lg mb-2 flex items-center">
                  <i className="fas fa-key text-[#ED4245] mr-2"></i> Other Commands
                </h2>
                {renderCommandSection(otherCommands, "fa-key", "bg-[#ED4245]")}
              </div>
            )}

            {searchTerm && 
             filterCommands([...generalCommands, ...carCommands, ...raceCommands, ...shopCommands, ...otherCommands]).length === 0 && (
              <div className="text-center py-10">
                <div className="w-16 h-16 mx-auto bg-[#36393F] rounded-full flex items-center justify-center mb-3">
                  <i className="fas fa-search text-[#DCDDDE] text-2xl"></i>
                </div>
                <h3 className="text-lg font-medium text-white mb-1">No Commands Found</h3>
                <p className="text-[#DCDDDE]">Try a different search term</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="faq" className="mt-4">
            <div className="space-y-4">
              <div className="bg-[#36393F] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-2">How do I get started?</h3>
                <p className="text-[#DCDDDE]">Register with <span className="bg-[#2F3136] px-2 py-1 rounded">!register</span> command to create an account. You'll get a starter car and some currency to begin your journey!</p>
              </div>
              
              <div className="bg-[#36393F] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-2">How do races work?</h3>
                <p className="text-[#DCDDDE]">Races are determined by your car's stats and the track type. Different tracks favor different car stats. The winner takes the entire bet amount from both players!</p>
              </div>
              
              <div className="bg-[#36393F] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-2">How can I earn more currency?</h3>
                <p className="text-[#DCDDDE]">You can earn currency by winning races, collecting daily rewards with <span className="bg-[#2F3136] px-2 py-1 rounded">!daily</span>, selling cars, and successfully stealing cars from other players.</p>
              </div>
              
              <div className="bg-[#36393F] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-2">What are the different car rarities?</h3>
                <p className="text-[#DCDDDE]">Cars come in five rarities: Common, Uncommon, Rare, Epic, and Legendary. Higher rarity cars have better stats but are more expensive.</p>
              </div>
              
              <div className="bg-[#36393F] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-2">Can I lose my cars?</h3>
                <p className="text-[#DCDDDE]">Yes! Other players can steal your cars with the <span className="bg-[#2F3136] px-2 py-1 rounded">!steal</span> command. Keep your best cars active to use them in races.</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="shortcuts" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-[#36393F] border-gray-700 p-4">
                <h3 className="text-white font-semibold mb-3">Quick Reference</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Check profile</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!profile</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">View balance</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!balance</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">See your cars</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!garage</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Daily reward</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!daily</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Visit shop</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!shop</span>
                  </div>
                </div>
              </Card>
              
              <Card className="bg-[#36393F] border-gray-700 p-4">
                <h3 className="text-white font-semibold mb-3">Common Actions</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Set active car</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!setactive 1</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Challenge to race</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!race @user 5000</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Buy a car</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!buy 3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Sell a car</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!sell 2</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#DCDDDE]">Try to steal</span>
                    <span className="bg-[#2F3136] px-2 py-0.5 rounded text-sm">!steal @user</span>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>
        </div>
      </Tabs>
      
      <Card className="bg-[#2F3136] border-gray-700 p-6">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 bg-[#5865F2] rounded-full flex items-center justify-center text-white mr-3">
            <i className="fas fa-headset text-xl"></i>
          </div>
          <div>
            <h2 className="text-white font-bold text-xl">Need More Help?</h2>
            <p className="text-[#DCDDDE]">Have questions or feedback? Let us know!</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#36393F] rounded-lg p-4">
            <h3 className="text-white font-semibold mb-2">Join Our Discord</h3>
            <p className="text-[#DCDDDE] mb-3">Get help from our community and staff members in real-time.</p>
            <Button 
              className="w-full bg-[#5865F2] hover:bg-opacity-80 text-white"
              onClick={() => window.open("https://discord.gg/trackbyte", "_blank")}
            >
              <i className="fab fa-discord mr-2"></i> Join Discord Server
            </Button>
          </div>
          
          <div className="bg-[#36393F] rounded-lg p-4">
            <h3 className="text-white font-semibold mb-2">Send Feedback</h3>
            <p className="text-[#DCDDDE] mb-3">Help us improve TrackByte with your suggestions.</p>
            <Button 
              className="w-full bg-[#57F287] hover:bg-opacity-80 text-white"
              onClick={handleFeedback}
            >
              <i className="fas fa-comment-alt mr-2"></i> Send Feedback
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
