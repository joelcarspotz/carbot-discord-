import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Car } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { toast } = useToast();
  
  // Use a dynamic user ID based on URL or default to user ID 1 (which has a proper username)
  const userId = 1; // Using a valid user ID from the database
  
  // Fetch user data
  const { data: user, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    onError: () => {
      toast({
        title: "Error fetching profile",
        description: "Could not retrieve your profile information",
        variant: "destructive"
      });
    }
  });

  // Fetch user's cars
  const { data: cars, isLoading: isLoadingCars } = useQuery<Car[]>({
    queryKey: [`/api/users/${userId}/cars`],
    onError: () => {
      toast({
        title: "Error fetching cars",
        description: "Could not retrieve your car collection",
        variant: "destructive"
      });
    }
  });
  
  // Fetch user's races
  const { data: races } = useQuery({
    queryKey: [`/api/users/${userId}/races`],
  });

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockUser: Partial<User> = {
    id: 1,
    username: "RacingKing",
    balance: 25750,
    activeCarId: 1,
    createdAt: new Date().toISOString()
  };

  // Get active car
  const activeCar = cars?.find(car => car.id === (user?.activeCarId || mockUser.activeCarId));
  
  // Calculate race stats
  const totalRaces = races?.length || 0;
  const wonRaces = races?.filter(race => race.winner === user?.id).length || 0;
  const winRate = totalRaces > 0 ? Math.round((wonRaces / totalRaces) * 100) : 0;

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-white mb-6">Driver Profile</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Profile Details */}
        <Card className="bg-[#2F3136] border-gray-700 col-span-1 p-6">
          {isLoadingUser ? (
            <div className="space-y-4">
              <Skeleton className="h-24 w-24 rounded-full mx-auto bg-[#36393F]" />
              <Skeleton className="h-6 w-3/4 mx-auto bg-[#36393F]" />
              <Skeleton className="h-4 w-2/4 mx-auto bg-[#36393F]" />
            </div>
          ) : (
            <>
              <div className="w-24 h-24 bg-[#5865F2] rounded-full flex items-center justify-center text-white mx-auto mb-4">
                <i className="fas fa-user text-3xl"></i>
              </div>
              <h2 className="text-xl font-bold text-white text-center">
                {user?.username || mockUser.username}
              </h2>
              <p className="text-[#DCDDDE] text-center">Driver</p>
            </>
          )}
          
          <div className="mt-6 space-y-4">
            <div className="flex justify-between">
              <span className="text-[#DCDDDE]">Balance:</span>
              <span className="text-[#FEE75C] font-semibold">₵{(user?.balance || mockUser.balance)?.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#DCDDDE]">Cars Owned:</span>
              <span className="text-white font-semibold">{cars?.length || '0'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#DCDDDE]">Member Since:</span>
              <span className="text-white font-semibold">
                {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
              </span>
            </div>
          </div>
        </Card>
        
        {/* Racing Stats */}
        <Card className="bg-[#2F3136] border-gray-700 col-span-3 p-6">
          <h2 className="text-xl font-bold text-white mb-4">Racing Statistics</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-[#36393F] rounded-lg p-4 text-center">
              <div className="text-3xl font-bold text-[#57F287]">{totalRaces}</div>
              <div className="text-[#DCDDDE] text-sm">Total Races</div>
            </div>
            <div className="bg-[#36393F] rounded-lg p-4 text-center">
              <div className="text-3xl font-bold text-[#FEE75C]">{wonRaces}</div>
              <div className="text-[#DCDDDE] text-sm">Races Won</div>
            </div>
            <div className="bg-[#36393F] rounded-lg p-4 text-center">
              <div className="text-3xl font-bold text-[#5865F2]">{winRate}%</div>
              <div className="text-[#DCDDDE] text-sm">Win Rate</div>
            </div>
          </div>
          
          <h3 className="text-lg font-semibold text-white mb-3">Active Car</h3>
          
          {isLoadingCars ? (
            <div className="bg-[#36393F] rounded-lg p-4">
              <div className="flex items-center">
                <Skeleton className="h-12 w-12 rounded-full mr-3 bg-[#2F3136]" />
                <div className="space-y-2">
                  <Skeleton className="h-5 w-32 bg-[#2F3136]" />
                  <Skeleton className="h-4 w-24 bg-[#2F3136]" />
                </div>
              </div>
            </div>
          ) : activeCar ? (
            <div className="bg-[#36393F] rounded-lg p-4">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-[#5865F2] flex items-center justify-center text-white mr-3">
                  <i className="fas fa-car text-xl"></i>
                </div>
                <div>
                  <h4 className="text-white font-semibold">{activeCar.name}</h4>
                  <p className="text-sm text-[#DCDDDE]">{activeCar.type} • {activeCar.rarity}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#DCDDDE]">Speed</span>
                    <span className="text-white">{activeCar.speed}/100</span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded overflow-hidden">
                    <div className="h-full bg-[#5865F2]" style={{ width: `${activeCar.speed}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#DCDDDE]">Acceleration</span>
                    <span className="text-white">{activeCar.acceleration}/100</span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded overflow-hidden">
                    <div className="h-full bg-[#57F287]" style={{ width: `${activeCar.acceleration}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#DCDDDE]">Handling</span>
                    <span className="text-white">{activeCar.handling}/100</span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded overflow-hidden">
                    <div className="h-full bg-[#FEE75C]" style={{ width: `${activeCar.handling}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#DCDDDE]">Boost</span>
                    <span className="text-white">{activeCar.boost}/100</span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded overflow-hidden">
                    <div className="h-full bg-purple-500" style={{ width: `${activeCar.boost}%` }}></div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#36393F] rounded-lg p-6 text-center">
              <p className="text-[#DCDDDE]">No active car set. Go to your garage to set an active car.</p>
            </div>
          )}
          
          <h3 className="text-lg font-semibold text-white mt-6 mb-3">Recent Achievements</h3>
          
          <div className="bg-[#36393F] rounded-lg p-4">
            <div className="flex items-center mb-3">
              <div className="w-10 h-10 rounded-full bg-[#FEE75C] flex items-center justify-center text-black mr-3">
                <i className="fas fa-trophy"></i>
              </div>
              <div>
                <h4 className="text-white font-semibold">Master Racer</h4>
                <p className="text-sm text-[#DCDDDE]">Won 10 races</p>
              </div>
              <div className="ml-auto">
                <span className="text-xs text-[#DCDDDE]">3 days ago</span>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center text-white mr-3">
                <i className="fas fa-car-side"></i>
              </div>
              <div>
                <h4 className="text-white font-semibold">Car Collector</h4>
                <p className="text-sm text-[#DCDDDE]">Owned 5 different cars</p>
              </div>
              <div className="ml-auto">
                <span className="text-xs text-[#DCDDDE]">1 week ago</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
