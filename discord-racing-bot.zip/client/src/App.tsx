import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Profile from "@/pages/Profile";
import Garage from "@/pages/Garage";
import Race from "@/pages/Race";
import Shop from "@/pages/Shop";
import Steal from "@/pages/Steal";
import Help from "@/pages/Help";
import Dashboard from "@/pages/Dashboard";
import { Sidebar } from "@/components/ui/sidebar";
import { Header } from "@/components/ui/header";

function Router() {
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#36393F] text-[#DCDDDE]">
      <Sidebar />
      <div className="flex-1 min-h-screen pb-20 md:pb-0">
        <Header />
        <main className="p-4 md:p-6">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/profile" component={Profile} />
            <Route path="/garage" component={Garage} />
            <Route path="/race" component={Race} />
            <Route path="/shop" component={Shop} />
            <Route path="/steal" component={Steal} />
            <Route path="/help" component={Help} />
            <Route path="/dashboard" component={Dashboard} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
