import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

type StealModalProps = {
  trigger?: React.ReactNode;
};

export function StealModal({ trigger }: StealModalProps) {
  const [open, setOpen] = useState(false);
  const [targetUser, setTargetUser] = useState("");
  const { toast } = useToast();

  const handleAttemptSteal = () => {
    if (!targetUser) {
      toast({
        title: "Error",
        description: "Please select a target user",
        variant: "destructive"
      });
      return;
    }

    // Generate random success (30% chance)
    const success = Math.random() < 0.3;

    if (success) {
      toast({
        title: "Theft Successful!",
        description: `You successfully stole a car from ${targetUser}!`,
        variant: "default"
      });
    } else {
      toast({
        title: "Theft Failed!",
        description: "You were caught and fined ₵5,000",
        variant: "destructive"
      });
    }
    
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button className="bg-[#ED4245] hover:bg-opacity-80 text-white">
            <i className="fas fa-key mr-2"></i> Steal Car
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="bg-[#2F3136] border-gray-700 text-[#DCDDDE]">
        <DialogHeader>
          <DialogTitle className="text-white font-bold flex items-center">
            <div className="bg-[#ED4245] p-2 rounded-full mr-2">
              <i className="fas fa-key text-white"></i>
            </div>
            Steal Attempt
          </DialogTitle>
        </DialogHeader>
        
        <div className="mb-6 text-center">
          <div className="w-20 h-20 mx-auto bg-[#ED4245] rounded-full flex items-center justify-center text-white mb-4">
            <i className="fas fa-key text-3xl"></i>
          </div>
          <h4 className="text-white font-medium text-lg mb-1">Attempt to steal a car?</h4>
          <p className="text-[#DCDDDE] text-sm">This action has a 30% success rate.<br/>If you fail, you'll be fined ₵5,000.</p>
        </div>
        
        <div className="bg-[#36393F] rounded-lg p-4 mb-6">
          <h4 className="text-white font-medium mb-2">Target User</h4>
          <Select value={targetUser} onValueChange={setTargetUser}>
            <SelectTrigger className="bg-[#2F3136] text-white border-gray-700">
              <SelectValue placeholder="Select a user" />
            </SelectTrigger>
            <SelectContent className="bg-[#2F3136] text-white border-gray-700">
              <SelectItem value="@RacingKing">@RacingKing</SelectItem>
              <SelectItem value="@SpeedDemon">@SpeedDemon</SelectItem>
              <SelectItem value="@DriftKing">@DriftKing</SelectItem>
              <SelectItem value="@CarCollector">@CarCollector</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="mt-4 flex items-center text-sm">
            <div className="flex-1">
              <div className="text-[#DCDDDE] mb-1">Cooldown</div>
              <div className="text-white">6 hours</div>
            </div>
            <div className="flex-1">
              <div className="text-[#DCDDDE] mb-1">Success Rate</div>
              <div className="text-[#57F287]">30%</div>
            </div>
            <div className="flex-1">
              <div className="text-[#DCDDDE] mb-1">Failure Fine</div>
              <div className="text-[#ED4245]">₵5,000</div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col space-y-2">
          <Button 
            className="bg-[#ED4245] hover:bg-opacity-80 text-white py-2 px-4 rounded font-medium"
            onClick={handleAttemptSteal}
          >
            Attempt Steal
          </Button>
          <Button 
            variant="outline"
            className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] py-2 px-4 rounded font-medium"
            onClick={() => setOpen(false)}
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
