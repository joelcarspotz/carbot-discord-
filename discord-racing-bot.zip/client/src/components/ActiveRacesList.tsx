import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Race } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export function ActiveRacesList() {
  const { toast } = useToast();
  
  const { data: races, isLoading } = useQuery({
    queryKey: ['/api/races'],
    onError: () => {
      toast({
        title: "Error fetching races",
        description: "Could not retrieve active races",
        variant: "destructive"
      });
    }
  });

  const handleJoinRace = (raceId: number) => {
    toast({
      title: "Join Race",
      description: `You're about to join race #${raceId}`,
      action: (
        <Button
          onClick={() => {
            toast({
              title: "Race joined",
              description: "You've joined the race. Good luck!",
            });
          }}
        >
          Confirm
        </Button>
      ),
    });
  };

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockRaces: Partial<Race>[] = [
    {
      id: 1,
      challenger: 2,
      bet: 10000,
      trackType: "street",
      status: "pending",
      createdAt: new Date().toISOString()
    }
  ];

  // Use real data if available, otherwise use mock data for UI demonstration
  const activeRaces = races?.length > 0 ? races : mockRaces;

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-white">Active Races</h2>
        <Button 
          className="bg-[#5865F2] hover:bg-opacity-80 text-white px-3 py-1 rounded-md text-sm"
        >
          <i className="fas fa-plus mr-1"></i> New Race
        </Button>
      </div>
      
      {isLoading ? (
        <div className="bg-[#2F3136] rounded-lg p-4 flex justify-center">
          <p>Loading races...</p>
        </div>
      ) : activeRaces.length > 0 ? (
        <div className="bg-[#2F3136] rounded-lg p-4 mb-4">
          {activeRaces.map((race) => (
            <div key={race.id} className="bg-[#36393F] rounded-lg p-4 flex flex-col md:flex-row justify-between items-center">
              <div className="flex items-center mb-4 md:mb-0">
                <div className="w-12 h-12 bg-[#5865F2] rounded-full flex items-center justify-center text-white mr-3">
                  <i className="fas fa-user text-xl"></i>
                </div>
                <div>
                  <h4 className="text-white font-medium">@RacingKing</h4>
                  <p className="text-sm text-[#DCDDDE]">McLaren P1 vs Challenger</p>
                </div>
              </div>
              
              <div className="flex items-center mb-4 md:mb-0">
                <div className="px-3 py-1 bg-[#2F3136] rounded text-[#FEE75C] text-sm mr-4">
                  <i className="fas fa-coins mr-1"></i> ₵{race.bet?.toLocaleString() ?? 0} Bet
                </div>
                <div className="px-3 py-1 bg-red-500 bg-opacity-20 rounded text-red-400 text-sm">
                  <i className="fas fa-clock mr-1"></i> 2:45 left
                </div>
              </div>
              
              <Button 
                className="bg-[#5865F2] hover:bg-opacity-80 text-white px-4 py-2 rounded w-full md:w-auto"
                onClick={() => handleJoinRace(race.id!)}
              >
                Join Race
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-[#DCDDDE] text-sm bg-[#2F3136] rounded-lg p-6">
          <p>No active races. Start one by challenging another player!</p>
        </div>
      )}
    </section>
  );
}
