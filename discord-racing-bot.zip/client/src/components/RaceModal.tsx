import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

type RaceModalProps = {
  trigger?: React.ReactNode;
};

export function RaceModal({ trigger }: RaceModalProps) {
  const [open, setOpen] = useState(false);
  const [betAmount, setBetAmount] = useState("5000");
  const [trackType, setTrackType] = useState("street");
  const { toast } = useToast();

  const handleSendChallenge = () => {
    toast({
      title: "Race Challenge Sent",
      description: `Your challenge with a bet of ₵${parseInt(betAmount).toLocaleString()} has been sent!`,
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button className="bg-[#5865F2] hover:bg-opacity-80 text-white">
            <i className="fas fa-flag-checkered mr-2"></i> Race Challenge
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="bg-[#2F3136] border-gray-700 text-[#DCDDDE]">
        <DialogHeader>
          <DialogTitle className="text-white font-bold flex items-center">
            <div className="bg-[#5865F2] p-2 rounded-full mr-2">
              <i className="fas fa-flag-checkered text-white"></i>
            </div>
            Race Challenge
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col md:flex-row justify-between mb-6">
          <div className="flex flex-col items-center mb-4 md:mb-0">
            <div className="w-16 h-16 bg-[#5865F2] rounded-full flex items-center justify-center text-white mb-2">
              <i className="fas fa-user text-2xl"></i>
            </div>
            <h4 className="text-white font-medium">@YourUsername</h4>
            <p className="text-sm text-[#DCDDDE]">McLaren P1</p>
          </div>
          
          <div className="flex items-center justify-center my-4">
            <div className="w-16 h-16 bg-[#2F3136] rounded-full flex items-center justify-center border-4 border-[#5865F2]">
              <i className="fas fa-flag-checkered text-2xl text-[#FEE75C]"></i>
            </div>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-[#ED4245] rounded-full flex items-center justify-center text-white mb-2">
              <i className="fas fa-user text-2xl"></i>
            </div>
            <h4 className="text-white font-medium">@Opponent</h4>
            <p className="text-sm text-[#DCDDDE]">Select opponent</p>
          </div>
        </div>
        
        <div className="bg-[#36393F] rounded-lg p-4 mb-6">
          <h4 className="text-white font-medium mb-2">Race Settings</h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[#DCDDDE] text-sm mb-1">Bet Amount</label>
              <div className="flex">
                <div className="bg-[#2F3136] flex items-center px-3 rounded-l border border-gray-700">
                  <i className="fas fa-coins text-[#FEE75C]"></i>
                </div>
                <Input 
                  type="text" 
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  className="bg-[#2F3136] text-white px-3 py-2 rounded-r border border-gray-700 w-full focus:outline-none focus:ring-1 focus:ring-[#5865F2]"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-[#DCDDDE] text-sm mb-1">Track Type</label>
              <Select value={trackType} onValueChange={setTrackType}>
                <SelectTrigger className="bg-[#2F3136] text-white border-gray-700">
                  <SelectValue placeholder="Select track type" />
                </SelectTrigger>
                <SelectContent className="bg-[#2F3136] text-white border-gray-700">
                  <SelectItem value="street">Street Race</SelectItem>
                  <SelectItem value="drag">Drag Race</SelectItem>
                  <SelectItem value="circuit">Circuit</SelectItem>
                  <SelectItem value="offroad">Off-road</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2">
          <Button 
            className="bg-[#5865F2] hover:bg-opacity-80 text-white py-2 px-4 rounded font-medium flex-1"
            onClick={handleSendChallenge}
          >
            Send Challenge
          </Button>
          <Button 
            variant="outline"
            className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] py-2 px-4 rounded font-medium"
            onClick={() => setOpen(false)}
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
