import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Car } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export function GarageDisplay() {
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();
  
  const { data: carsData, isLoading } = useQuery({
    queryKey: ['/api/users/1/cars'], // In a real app, this would be the logged-in user's ID
    onError: () => {
      toast({
        title: "Error fetching cars",
        description: "Could not retrieve your car collection",
        variant: "destructive"
      });
    }
  });

  const handleRace = (carId: number) => {
    toast({
      title: "Race initiated",
      description: `Preparing your car (ID: ${carId}) for a race`,
    });
  };

  const handleSell = (carId: number, value: number) => {
    toast({
      title: "Sell car",
      description: `Are you sure you want to sell this car for ₵${value.toLocaleString()}?`,
      action: (
        <Button
          variant="destructive"
          onClick={() => {
            toast({
              title: "Car sold",
              description: `You sold your car for ₵${value.toLocaleString()}`,
            });
          }}
        >
          Confirm
        </Button>
      ),
    });
  };

  // Pagination logic
  const carsPerPage = 3;
  const totalCars = carsData?.length || 0;
  const totalPages = Math.ceil(totalCars / carsPerPage);
  
  const startIndex = (currentPage - 1) * carsPerPage;
  const displayedCars = carsData?.slice(startIndex, startIndex + carsPerPage) || [];

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(prev => prev - 1);
    }
  };

  // Helper function for rarity color styling
  const getRarityStyles = (rarity: string) => {
    switch(rarity) {
      case 'Legendary':
        return {
          border: 'border-yellow-500',
          badge: 'bg-yellow-500',
          badgeText: 'text-black',
          bgColor: 'bg-yellow-500 bg-opacity-10',
          textColor: 'text-yellow-300'
        };
      case 'Rare':
        return {
          border: 'border-blue-500',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-blue-500 bg-opacity-10',
          textColor: 'text-blue-400'
        };
      case 'Common':
        return {
          border: 'border-gray-700',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-green-500 bg-opacity-10',
          textColor: 'text-green-400'
        };
      default:
        return {
          border: 'border-gray-700',
          badge: 'bg-[#36393F]',
          badgeText: 'text-[#DCDDDE]',
          bgColor: 'bg-blue-500 bg-opacity-10',
          textColor: 'text-blue-400'
        };
    }
  };

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockCars: Car[] = [
    {
      id: 1,
      userId: 1,
      name: "McLaren P1",
      type: "Hypercar",
      rarity: "Legendary",
      speed: 95,
      acceleration: 90,
      handling: 85,
      boost: 80,
      value: 75000,
      image: "mclaren.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 2,
      userId: 1,
      name: "Porsche 911",
      type: "Sports Car",
      rarity: "Rare",
      speed: 80,
      acceleration: 85,
      handling: 90,
      boost: 65,
      value: 35000,
      image: "porsche.svg",
      acquired: new Date().toISOString()
    },
    {
      id: 3,
      userId: 1,
      name: "Honda Civic",
      type: "Economy",
      rarity: "Common",
      speed: 55,
      acceleration: 60,
      handling: 70,
      boost: 40,
      value: 5000,
      image: "civic.svg",
      acquired: new Date().toISOString()
    }
  ];

  // Use real data if available, otherwise use mock data for UI demonstration
  const cars = displayedCars.length > 0 ? displayedCars : mockCars;

  return (
    <div className="bg-[#2F3136] rounded-lg p-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">Your Garage</h3>
        <div className="flex space-x-2">
          <div className="text-sm bg-[#36393F] rounded-md px-3 py-1 flex items-center">
            <i className="fas fa-car-side mr-2 text-[#DCDDDE]"></i>
            <span className="font-medium">{isLoading ? "Loading..." : `${totalCars}/10`}</span>
          </div>
          <Button 
            size="sm" 
            className="bg-[#5865F2] hover:bg-opacity-80 text-white text-sm px-3 py-1 rounded-md"
          >
            <i className="fas fa-plus mr-1"></i> Expand
          </Button>
        </div>
      </div>
      
      {/* Cars grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cars.map((car) => {
          const styles = getRarityStyles(car.rarity);
          const isActive = car.id === 1; // In a real app, check if car.id matches activeCarId
          
          return (
            <div 
              key={car.id} 
              className={`bg-gradient-to-br from-[#36393F] to-[#2F3136] rounded-lg overflow-hidden ${styles.border} ${isActive ? 'border' : 'border border-gray-700'}`}
            >
              <div className={`p-3 ${styles.bgColor} flex justify-between items-center`}>
                <span className={`${styles.textColor} font-semibold`}>{car.rarity}</span>
                <div className={`${styles.badge} ${styles.badgeText} text-xs font-bold px-2 py-1 rounded`}>
                  {isActive ? 'ACTIVE' : 'GARAGE'}
                </div>
              </div>
              <div className="p-4">
                <h4 className="text-white font-semibold text-lg mb-1">{car.name}</h4>
                <p className="text-[#DCDDDE] text-sm mb-3">{car.type}</p>
                
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-[#36393F] rounded p-2">
                    <div className="text-xs text-[#DCDDDE] mb-1">Speed</div>
                    <div className="h-2 bg-gray-700 rounded overflow-hidden">
                      <div className="h-full bg-[#5865F2]" style={{ width: `${car.speed}%` }}></div>
                    </div>
                  </div>
                  <div className="bg-[#36393F] rounded p-2">
                    <div className="text-xs text-[#DCDDDE] mb-1">Acceleration</div>
                    <div className="h-2 bg-gray-700 rounded overflow-hidden">
                      <div className="h-full bg-[#57F287]" style={{ width: `${car.acceleration}%` }}></div>
                    </div>
                  </div>
                  <div className="bg-[#36393F] rounded p-2">
                    <div className="text-xs text-[#DCDDDE] mb-1">Handling</div>
                    <div className="h-2 bg-gray-700 rounded overflow-hidden">
                      <div className="h-full bg-[#FEE75C]" style={{ width: `${car.handling}%` }}></div>
                    </div>
                  </div>
                  <div className="bg-[#36393F] rounded p-2">
                    <div className="text-xs text-[#DCDDDE] mb-1">Boost</div>
                    <div className="h-2 bg-gray-700 rounded overflow-hidden">
                      <div className="h-full bg-purple-500" style={{ width: `${car.boost}%` }}></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button 
                    className="flex-1 bg-[#5865F2] hover:bg-opacity-80 text-white text-sm py-1 rounded"
                    onClick={() => handleRace(car.id)}
                  >
                    Race
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1 bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] text-sm py-1 rounded"
                    onClick={() => handleSell(car.id, car.value)}
                  >
                    Sell (₵{car.value.toLocaleString()})
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="flex justify-center mt-4">
        <Button 
          variant="outline"
          size="sm"
          className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] px-3 py-1 rounded mr-2 text-sm"
          onClick={prevPage}
          disabled={currentPage === 1}
        >
          <i className="fas fa-chevron-left"></i>
        </Button>
        <span className="bg-[#36393F] text-[#DCDDDE] px-3 py-1 rounded text-sm">
          Page {currentPage} of {Math.max(1, totalPages)}
        </span>
        <Button 
          variant="outline"
          size="sm"
          className="bg-[#36393F] hover:bg-[#4F545C] text-[#DCDDDE] px-3 py-1 rounded ml-2 text-sm"
          onClick={nextPage}
          disabled={currentPage === totalPages || totalPages === 0}
        >
          <i className="fas fa-chevron-right"></i>
        </Button>
      </div>
    </div>
  );
}
