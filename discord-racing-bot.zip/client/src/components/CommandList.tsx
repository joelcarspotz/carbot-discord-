import { Card } from "@/components/ui/card";

type Command = {
  id: string;
  name: string;
  description: string;
  usage: string;
  icon: string;
  color: string;
};

const commands: Command[] = [
  {
    id: "profile",
    name: "!profile",
    description: "View your driver profile",
    usage: "!profile [@user]",
    icon: "fa-user",
    color: "bg-[#5865F2]",
  },
  {
    id: "garage",
    name: "!garage",
    description: "View your car collection",
    usage: "!garage [page]",
    icon: "fa-car",
    color: "bg-[#57F287]",
  },
  {
    id: "race",
    name: "!race",
    description: "Race against other players",
    usage: "!race [@user] [bet]",
    icon: "fa-flag-checkered",
    color: "bg-[#FEE75C]",
  },
  {
    id: "shop",
    name: "!shop",
    description: "Browse available cars",
    usage: "!shop [category]",
    icon: "fa-store",
    color: "bg-[#5865F2]",
  },
  {
    id: "steal",
    name: "!steal",
    description: "Attempt to steal a car",
    usage: "!steal [@user]",
    icon: "fa-key",
    color: "bg-[#ED4245]",
  },
  {
    id: "help",
    name: "!help",
    description: "View all commands",
    usage: "!help [command]",
    icon: "fa-question",
    color: "bg-[#36393F]",
  },
];

export function CommandList() {
  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Welcome to TrackByte</h2>
        <div className="text-sm text-[#DCDDDE] bg-[#2F3136] rounded-md px-3 py-1">
          Prefix: <span className="text-[#5865F2] font-semibold">!</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {commands.map((command) => (
          <Card key={command.id} className="bg-[#2F3136] rounded-lg p-4 hover:bg-opacity-80 transition-colors">
            <div className="flex items-center mb-2">
              <div className={`w-10 h-10 rounded-full ${command.color} flex items-center justify-center mr-3`}>
                <i className={`fas ${command.icon} ${command.id === 'race' ? 'text-black' : 'text-white'}`}></i>
              </div>
              <div>
                <h3 className="font-semibold text-white">{command.name}</h3>
                <p className="text-sm text-[#DCDDDE]">{command.description}</p>
              </div>
            </div>
            <div className="text-xs text-[#DCDDDE] border-t border-gray-700 pt-2 mt-2">
              Usage: <span className="bg-[#36393F] px-2 py-1 rounded">{command.usage}</span>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}
