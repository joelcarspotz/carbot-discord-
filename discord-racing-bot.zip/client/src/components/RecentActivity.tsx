import { useQuery } from "@tanstack/react-query";
import { ActivityLog } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export function RecentActivity() {
  const { toast } = useToast();
  
  const { data: activityLogs, isLoading } = useQuery({
    queryKey: ['/api/activity'],
    onError: () => {
      toast({
        title: "Error fetching activity",
        description: "Could not retrieve recent activity",
        variant: "destructive"
      });
    }
  });

  // Helper to format time
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hours ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} days ago`;
  };

  // Helper to determine icon and color based on activity type
  const getActivityStyles = (type: string) => {
    switch(type) {
      case 'race_completed':
        return { icon: 'fa-flag-checkered', color: 'bg-[#57F287]' };
      case 'car_purchased':
        return { icon: 'fa-shopping-cart', color: 'bg-[#5865F2]' };
      case 'steal_failed':
        return { icon: 'fa-key', color: 'bg-[#ED4245]' };
      case 'car_stolen':
        return { icon: 'fa-key', color: 'bg-[#ED4245]' };
      case 'car_acquired':
        return { icon: 'fa-star', color: 'bg-yellow-500' };
      default:
        return { icon: 'fa-car-side', color: 'bg-[#5865F2]' };
    }
  };

  // Mock data for UI demonstration - this would be replaced by real data in production
  const mockActivity: Partial<ActivityLog>[] = [
    {
      id: 1,
      type: 'race_completed',
      userId: 1,
      targetId: 2,
      details: { winner: 1 },
      createdAt: new Date(Date.now() - 2 * 60000).toISOString() // 2 minutes ago
    },
    {
      id: 2,
      type: 'car_purchased',
      userId: 3,
      details: { carName: 'Nissan GT-R', price: 45000, rarity: 'Rare' },
      createdAt: new Date(Date.now() - 15 * 60000).toISOString() // 15 minutes ago
    },
    {
      id: 3,
      type: 'steal_failed',
      userId: 4,
      targetId: 5,
      details: { fine: 5000 },
      createdAt: new Date(Date.now() - 45 * 60000).toISOString() // 45 minutes ago
    },
    {
      id: 4,
      type: 'car_acquired',
      userId: 6,
      details: { carName: 'Bugatti Chiron', rarity: 'Legendary' },
      createdAt: new Date(Date.now() - 2 * 3600000).toISOString() // 2 hours ago
    }
  ];

  // Use real data if available, otherwise use mock data for UI demonstration
  const activities = activityLogs?.length > 0 ? activityLogs : mockActivity;

  return (
    <section>
      <h2 className="text-xl font-semibold text-white mb-4">Recent Activity</h2>
      
      {isLoading ? (
        <div className="bg-[#2F3136] rounded-lg p-4 flex justify-center">
          <p>Loading activity...</p>
        </div>
      ) : (
        <div className="bg-[#2F3136] rounded-lg divide-y divide-gray-700">
          {activities.map((activity) => {
            const { icon, color } = getActivityStyles(activity.type || '');
            let content = '';
            
            // Determine content based on activity type
            switch(activity.type) {
              case 'race_completed':
                content = (
                  <p className="text-[#DCDDDE]">
                    <span className="text-white font-medium">@SpeedDemon</span> won a race against 
                    <span className="text-white font-medium"> @DriftKing</span> and earned
                    <span className="text-[#FEE75C]"> ₵15,000</span>
                  </p>
                );
                break;
              case 'car_purchased':
                content = (
                  <p className="text-[#DCDDDE]">
                    <span className="text-white font-medium">@CarCollector</span> purchased a 
                    <span className="text-blue-400 font-medium"> {activity.details?.rarity} {activity.details?.carName}</span> for
                    <span className="text-[#FEE75C]"> ₵{(activity.details?.price as number)?.toLocaleString() ?? 0}</span>
                  </p>
                );
                break;
              case 'steal_failed':
                content = (
                  <p className="text-[#DCDDDE]">
                    <span className="text-white font-medium">@MidnightThief</span> failed to steal a car from 
                    <span className="text-white font-medium"> @VaultKeeper</span> and paid a
                    <span className="text-[#FEE75C]"> ₵{(activity.details?.fine as number)?.toLocaleString() ?? 0}</span> fine
                  </p>
                );
                break;
              case 'car_acquired':
                content = (
                  <p className="text-[#DCDDDE]">
                    <span className="text-white font-medium">@LuckyDriver</span> found a 
                    <span className="text-yellow-300 font-medium"> {activity.details?.rarity} {activity.details?.carName}</span> in a
                    <span className="text-purple-400 font-medium"> Mystery Box</span>
                  </p>
                );
                break;
              default:
                content = (
                  <p className="text-[#DCDDDE]">
                    <span className="text-white font-medium">@User</span> performed an action
                  </p>
                );
            }
            
            return (
              <div key={activity.id} className="p-4 flex items-start">
                <div className={`w-10 h-10 rounded-full ${color} flex items-center justify-center mr-3 flex-shrink-0`}>
                  <i className={`fas ${icon} ${icon === 'fa-star' ? 'text-black' : 'text-white'}`}></i>
                </div>
                <div>
                  {content}
                  <p className="text-xs text-[#4F545C] mt-1">{formatTime(activity.createdAt || '')}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
