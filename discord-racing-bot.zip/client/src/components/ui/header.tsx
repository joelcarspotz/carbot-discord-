import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { UserCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function Header() {
  const { toast } = useToast();
  
  const { data: userBalance, isLoading } = useQuery({
    queryKey: ['/api/users/1'], // In a real app, this would be the logged-in user's ID
    onError: () => {
      toast({
        title: "Error fetching user data",
        description: "Could not retrieve your account information",
        variant: "destructive"
      });
    }
  });

  const handleUserSettings = () => {
    toast({
      title: "User Settings",
      description: "Settings functionality coming soon!",
    });
  };

  return (
    <header className="bg-[#2F3136] p-4 border-b border-black flex justify-between items-center">
      <div className="flex items-center">
        <i className="fas fa-car-side text-[#5865F2] mr-3 text-2xl"></i>
        <h1 className="text-white text-xl font-semibold">TrackByte</h1>
      </div>
      <div className="flex items-center">
        <div className="bg-[#36393F] rounded-full px-3 py-1 flex items-center mr-3">
          <i className="fas fa-coins text-[#FEE75C] mr-2"></i>
          <span className="font-medium">
            {isLoading ? "Loading..." : (userBalance ? userBalance.balance.toLocaleString() : '0')}
          </span>
        </div>
        <div className="tooltip">
          <Button 
            variant="ghost" 
            size="icon" 
            className="bg-[#5865F2] hover:bg-opacity-80 text-white rounded-full w-10 h-10"
            onClick={handleUserSettings}
          >
            <UserCircle className="h-5 w-5" />
          </Button>
          <span className="tooltip-text">User Settings</span>
        </div>
      </div>
    </header>
  );
}
