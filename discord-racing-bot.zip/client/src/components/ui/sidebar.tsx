import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

type SidebarItemProps = {
  icon: string;
  label: string;
  href: string;
  active?: boolean;
  color?: string;
};

const SidebarItem = ({ icon, label, href, active, color }: SidebarItemProps) => {
  return (
    <div className="tooltip mb-4">
      <Link href={href}>
        <a className="block">
          <div 
            className={cn(
              "w-12 h-12 rounded-full flex items-center justify-center cursor-pointer transition-colors",
              active 
                ? "bg-[#5865F2]" 
                : "bg-[#2F3136] hover:bg-[#5865F2]",
              color === "green" && active && "bg-[#57F287]",
              color === "red" && active && "bg-[#ED4245]"
            )}
          >
            <i className={`fas ${icon} ${active ? "text-white" : "text-[#DCDDDE]"} text-xl`}></i>
          </div>
        </a>
      </Link>
      <span className="tooltip-text">{label}</span>
    </div>
  );
};

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="bg-[#202225] w-full md:w-16 md:min-h-screen flex flex-col items-center py-4 md:py-6 order-last md:order-first fixed bottom-0 md:relative z-10">
      <div className="tooltip mb-6">
        <div className="bg-[#5865F2] rounded-full w-12 h-12 flex items-center justify-center cursor-pointer">
          <i className="fas fa-car-side text-white text-xl"></i>
        </div>
        <span className="tooltip-text">TrackByte</span>
      </div>
      
      <div className="h-px w-8 bg-[#4F545C] mb-4"></div>
      
      <SidebarItem 
        icon="fa-home" 
        label="Home" 
        href="/" 
        active={location === "/"} 
        color="green"
      />
      
      <SidebarItem 
        icon="fa-tachometer-alt" 
        label="Dashboard" 
        href="/dashboard" 
        active={location === "/dashboard"}
        color="blue"
      />
      
      <SidebarItem 
        icon="fa-user" 
        label="Profile" 
        href="/profile" 
        active={location === "/profile"}
      />
      
      <SidebarItem 
        icon="fa-flag-checkered" 
        label="Race" 
        href="/race" 
        active={location === "/race"}
      />
      
      <SidebarItem 
        icon="fa-store" 
        label="Shop" 
        href="/shop" 
        active={location === "/shop"}
      />
      
      <SidebarItem 
        icon="fa-key" 
        label="Steal" 
        href="/steal" 
        active={location === "/steal"} 
        color="red"
      />
      
      <SidebarItem 
        icon="fa-question" 
        label="Help" 
        href="/help" 
        active={location === "/help"}
      />
    </div>
  );
}
