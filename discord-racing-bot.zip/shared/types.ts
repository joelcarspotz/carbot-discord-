export interface CarData {
  name: string;
  type: string;
  rarity: string;
  speed: number;
  acceleration: number;
  handling: number;
  boost: number;
  value: number;
}