import 'dotenv/config';
import { startBot } from '../server/discord/bot.ts';

// Start the Discord bot
startBot().catch(err => {
  console.error('Error starting bot:', err);
  process.exit(1);
});